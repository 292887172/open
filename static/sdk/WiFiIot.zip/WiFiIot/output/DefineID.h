//��������Main����������ID
#define  _SCREEN_MAIN                                                          0

//��������Setting����������ID
#define  _SCREEN_SETTING                                                       1

//��������WiFi����������ID
#define  _SCREEN_WIFI                                                          2

//��������Qrcode����������ID
#define  _SCREEN_QRCODE                                                        3

//��������Dialog����������ID
#define  _SCREEN_DIALOG                                                        4

//��������Loading����������ID
#define  _SCREEN_LOADING                                                       5

//��������WiFiConfig����������ID
#define  _SCREEN_WIFICONFIG                                                    6

//��������Lock����������ID
#define  _SCREEN_LOCK                                                          7

//��������SSID1����������ID
#define  _SCREEN_SSID1                                                         8

//��������SSID2����������ID
#define  _SCREEN_SSID2                                                         9

//��������ProductCenter����������ID
#define  _SCREEN_PRODUCTCENTER                                                10

//��������ProductCooper����������ID
#define  _SCREEN_PRODUCTCOOPER                                                11

//��������LinkUs����������ID
#define  _SCREEN_LINKUS                                                       12

#define  _RTC_MAIN_RTC1                                                       11

#define  _BTN_MAIN_BUTTON2                                                    26

#define  _BTN_MAIN_BUTTON3                                                    23

#define  _TXT_DIS__MAIN_TEXT_DISPLAY1                                         99

#define  _TXT_DIS__MAIN_TEXT_DISPLAY2                                        100

#define  _BTN_MAIN_BUTTON12                                                   10

#define  _BTN_MAIN_BUTTON7                                                   111

#define  _BTN_MAIN_BUTTON4                                                    31

#define  _BTN_MAIN_BUTTON5                                                   112

#define  _BTN_MAIN_BUTTON6                                                   113

#define  _BTN_MAIN_BUTTON8                                                   103

#define  _BTN_MAIN_BUTTON9                                                   102

#define  _BTN_MAIN_BUTTON10                                                  101

#define  _BTN_MAIN_BUTTON1                                                     1

#define  _BTN_MAIN_BUTTON11                                                   21

#define  _TXT_DIS__MAIN_TEXT_DISPLAY3                                        110

#define  _TXT_DIS__MAIN_TEXT_DISPLAY4                                          2

#define  _BTN_SETTING_BUTTON2                                                 52

#define  _SELECTOR_SETTING_SELECTOR1                                          53

#define  _TXT_DIS__SETTING_TEXT_DISPLAY3                                      54

#define  _TXT_DIS__SETTING_TEXT_DISPLAY4                                      55

#define  _RTC_SETTING_RTC1                                                    11

#define  _BTN_SETTING_BUTTON1                                                 12

#define  _PROGRESS_SETTING_PROGRESS1                                          62

#define  _SLIDER_SETTING_SLIDER1                                              63

#define  _BTN_SETTING_BUTTON3                                                 82

#define  _TXT_DIS__SETTING_TEXT_DISPLAY9                                      92

#define  _BTN_SETTING_BUTTON10                                                93

#define  _TXT_DIS__SETTING_TEXT_DISPLAY10                                    999

#define  _TXT_DIS__SETTING_TEXT_DISPLAY11                                   1000

#define  _PROGRESS_SETTING_PROGRESS2                                          94

//����Setting�а�ťButton11����ʱ��ͼƬ
#define  _IMG_SETTING_BUTTON11_UP                                             31

//����Setting�а�ťButton11����ʱ��ͼƬ
#define  _IMG_SETTING_BUTTON11_DOWN                                           32

#define  _BTN_SETTING_BUTTON11                                               102

#define  _SELECTOR_SETTING_SELECTOR2                                          95

#define  _TXT_DIS__SETTING_TEXT_DISPLAY13                                     83

#define  _BTN_SETTING_BUTTON12                                                84

//����Setting�а�ťButton13����ʱ��ͼƬ
#define  _IMG_SETTING_BUTTON13_UP                                             31

//����Setting�а�ťButton13����ʱ��ͼƬ
#define  _IMG_SETTING_BUTTON13_DOWN                                           32

#define  _BTN_SETTING_BUTTON13                                                77

#define  _RTC_SETTING_RTC2                                                    72

#define  _TXT_DIS__SETTING_TEXT_DISPLAY2                                      73

#define  _TXT_DIS__SETTING_TEXT_DISPLAY15                                     85

#define  _TXT_DIS__SETTING_TEXT_DISPLAY16                                     96

//����Setting�а�ťButton15����ʱ��ͼƬ
#define  _IMG_SETTING_BUTTON15_UP                                             31

//����Setting�а�ťButton15����ʱ��ͼƬ
#define  _IMG_SETTING_BUTTON15_DOWN                                           32

#define  _BTN_SETTING_BUTTON15                                               112

#define  _BTN_SETTING_BUTTON9                                                 10

#define  _BTN_SETTING_BUTTON14                                               104

#define  _BTN_SETTING_BUTTON16                                               103

#define  _SELECTOR_SETTING_SELECTOR3                                         122

#define  _BTN_SETTING_BUTTON17                                               123

//����Setting�а�ťButton18����ʱ��ͼƬ
#define  _IMG_SETTING_BUTTON18_DOWN                                           36

#define  _BTN_SETTING_BUTTON18                                               124

//����Setting�а�ťButton19����ʱ��ͼƬ
#define  _IMG_SETTING_BUTTON19_DOWN                                           36

#define  _BTN_SETTING_BUTTON19                                               125

#define  _BTN_SETTING_BUTTON20                                               132

#define  _BTN_SETTING_BUTTON4                                                 26

#define  _BTN_SETTING_BUTTON5                                                 23

#define  _BTN_SETTING_BUTTON6                                                 31

#define  _ANIMATION_SETTING_ICON1                                             97

//����WiFi�ı���ͼƬ
#define  _IMG_WIFI                                                            23

//����WiFi��ͼƬImage2ʹ�õ�ͼƬ
#define  _IMG_WIFI_IMAGE2                                                     24

#define  _BTN_WIFI_BUTTON2                                                    51

//����WiFi�а�ťButton8����ʱ��ͼƬ
#define  _IMG_WIFI_BUTTON8_UP                                                 25

//����WiFi�а�ťButton8����ʱ��ͼƬ
#define  _IMG_WIFI_BUTTON8_DOWN                                               26

#define  _BTN_WIFI_BUTTON8                                                    12

#define  _SELECTOR_WIFI_SELECTOR1                                             53

#define  _TXT_DIS__WIFI_TEXT_DISPLAY11                                        54

#define  _TXT_DIS__WIFI_TEXT_DISPLAY12                                        55

#define  _RTC_WIFI_RTC1                                                       11

#define  _TXT_DIS__WIFI_TEXT_DISPLAY13                                        99

#define  _TXT_DIS__WIFI_TEXT_DISPLAY14                                       100

#define  _ANIMATION_WIFI_ANIMATION1                                           56

#define  _SCREENCONTAINER_WIFI_SCREENCONTAINER1                                2

//����WiFi�а�ťButton9����ʱ��ͼƬ
#define  _IMG_WIFI_BUTTON9_UP                                                 33

#define  _BTN_WIFI_BUTTON9                                                    10

//����WiFi�а�ťButton4����ʱ��ͼƬ
#define  _IMG_WIFI_BUTTON4_UP                                                 37

//����WiFi�а�ťButton4����ʱ��ͼƬ
#define  _IMG_WIFI_BUTTON4_DOWN                                               38

#define  _BTN_WIFI_BUTTON4                                                    26

//����WiFi�а�ťButton5����ʱ��ͼƬ
#define  _IMG_WIFI_BUTTON5_UP                                                 39

//����WiFi�а�ťButton5����ʱ��ͼƬ
#define  _IMG_WIFI_BUTTON5_DOWN                                               40

#define  _BTN_WIFI_BUTTON5                                                    23

//����WiFi�а�ťButton6����ʱ��ͼƬ
#define  _IMG_WIFI_BUTTON6_UP                                                 41

//����WiFi�а�ťButton6����ʱ��ͼƬ
#define  _IMG_WIFI_BUTTON6_DOWN                                               42

#define  _BTN_WIFI_BUTTON6                                                    31

//����Qrcode�ı���ͼƬ
#define  _IMG_QRCODE                                                          23

#define  _TXT_DIS__QRCODE_TEXT_DISPLAY2                                        4

#define  _QCODE_QRCODE_QRCODE1                                                 2

#define  _TXT_DIS__QRCODE_TEXT_DISPLAY1                                        3

//����Qrcode�а�ťButton1����ʱ��ͼƬ
#define  _IMG_QRCODE_BUTTON1_UP                                               25

//����Qrcode�а�ťButton1����ʱ��ͼƬ
#define  _IMG_QRCODE_BUTTON1_DOWN                                             26

#define  _BTN_QRCODE_BUTTON1                                                  12

//����Qrcode��ͼƬImage2ʹ�õ�ͼƬ
#define  _IMG_QRCODE_IMAGE2                                                   24

#define  _TXT_DIS__QRCODE_TEXT_DISPLAY3                                       99

#define  _TXT_DIS__QRCODE_TEXT_DISPLAY4                                      100

#define  _RTC_QRCODE_RTC1                                                     11

//����Qrcode�а�ťButton12����ʱ��ͼƬ
#define  _IMG_QRCODE_BUTTON12_UP                                              33

#define  _BTN_QRCODE_BUTTON12                                                 10

#define  _TXT_DIS__QRCODE_TEXT_DISPLAY5                                        5

#define  _TXT_DIS__QRCODE_TEXT_DISPLAY6                                        6

#define  _TXT_DIS__QRCODE_TEXT_DISPLAY7                                        7

#define  _TXT_DIS__QRCODE_TEXT_DISPLAY8                                        8

#define  _TXT_DIS__QRCODE_TEXT_DISPLAY17                                     111

//����Qrcode�а�ťButton15����ʱ��ͼƬ
#define  _IMG_QRCODE_BUTTON15_UP                                              31

//����Qrcode�а�ťButton15����ʱ��ͼƬ
#define  _IMG_QRCODE_BUTTON15_DOWN                                            32

#define  _BTN_QRCODE_BUTTON15                                                112

//����Qrcode�а�ťButton4����ʱ��ͼƬ
#define  _IMG_QRCODE_BUTTON4_UP                                               37

//����Qrcode�а�ťButton4����ʱ��ͼƬ
#define  _IMG_QRCODE_BUTTON4_DOWN                                             38

#define  _BTN_QRCODE_BUTTON4                                                  26

//����Qrcode�а�ťButton5����ʱ��ͼƬ
#define  _IMG_QRCODE_BUTTON5_UP                                               39

//����Qrcode�а�ťButton5����ʱ��ͼƬ
#define  _IMG_QRCODE_BUTTON5_DOWN                                             40

#define  _BTN_QRCODE_BUTTON5                                                  23

//����Qrcode�а�ťButton6����ʱ��ͼƬ
#define  _IMG_QRCODE_BUTTON6_UP                                               41

//����Qrcode�а�ťButton6����ʱ��ͼƬ
#define  _IMG_QRCODE_BUTTON6_DOWN                                             42

#define  _BTN_QRCODE_BUTTON6                                                  31

#define  _TXT_DIS__DIALOG_TEXT_DISPLAY1                                        2

#define  _TXT_DIS__DIALOG_TEXT_DISPLAY2                                        3

#define  _BTN_DIALOG_BUTTON1                                                   7

#define  _TXT_DIS__DIALOG_TEXT_DISPLAY3                                      999

#define  _TXT_DIS__DIALOG_TEXT_DISPLAY4                                     1000

//����Dialog�а�ťButton2����ʱ��ͼƬ
#define  _IMG_DIALOG_BUTTON2_UP                                               47

#define  _BTN_DIALOG_BUTTON2                                                   8

#define  _ANIMATION_LOADING_ANIMATION1                                         1

#define  _BTN_LOADING_BUTTON1                                                  2

//����WiFiConfig��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_WIFICONFIG_IMAGE1                                               46

#define  _TXT_DIS__WIFICONFIG_TEXT_DISPLAY1                                    2

#define  _BTN_WIFICONFIG_BUTTON1                                               5

#define  _TXT_DIS__WIFICONFIG_TEXT_DISPLAY3                                   13

#define  _BTN_WIFICONFIG_BUTTON2                                               6

#define  _TXT_DIS__WIFICONFIG_TEXT_DISPLAY4                                  999

#define  _TXT_DIS__WIFICONFIG_TEXT_DISPLAY5                                  100

#define  _TXT_DIS__WIFICONFIG_TEXT_DISPLAY6                                    8

#define  _ANIMATION_WIFICONFIG_ANIMATION1                                      9

#define  _BTN_WIFICONFIG_BUTTON3                                               7

#define  _TXT_DIS__WIFICONFIG_TEXT_DISPLAY8                                    4

#define  _TXT_DIS__WIFICONFIG_TEXT_DISPLAY2                                    3

#define  _TXT_DIS__WIFICONFIG_TEXT_DISPLAY7                                   11

#define  _SELECTOR_WIFICONFIG_SELECTOR1                                       12

#define  _IMAGE_LOCK_IMAGE1                                                    4

#define  _BTN_LOCK_BUTTON1                                                     1

#define  _TXT_DIS__LOCK_TEXT_DISPLAY1                                         99

#define  _TXT_DIS__LOCK_TEXT_DISPLAY2                                        100

//����Lock�а�ťButton12����ʱ��ͼƬ
#define  _IMG_LOCK_BUTTON12_UP                                                33

#define  _BTN_LOCK_BUTTON12                                                   10

#define  _TXT_DIS__LOCK_TEXT_DISPLAY3                                          3

#define  _TXT_DIS__SSID1_TEXT_DISPLAY1                                        61

#define  _TXT_DIS__SSID1_TEXT_DISPLAY2                                        62

#define  _TXT_DIS__SSID1_TEXT_DISPLAY3                                        63

#define  _TXT_DIS__SSID1_TEXT_DISPLAY4                                        64

#define  _TXT_DIS__SSID1_TEXT_DISPLAY5                                        65

#define  _TXT_DIS__SSID1_TEXT_DISPLAY6                                        66

#define  _TXT_DIS__SSID1_TEXT_DISPLAY7                                        67

#define  _TXT_DIS__SSID1_TEXT_DISPLAY8                                        68

#define  _TXT_DIS__SSID1_TEXT_DISPLAY9                                        70

#define  _TXT_DIS__SSID1_TEXT_DISPLAY10                                       69

#define  _BTN_SSID1_BUTTON1                                                   71

#define  _BTN_SSID1_BUTTON3                                                   72

#define  _BTN_SSID1_BUTTON4                                                   73

#define  _BTN_SSID1_BUTTON5                                                   74

#define  _BTN_SSID1_BUTTON6                                                   75

#define  _BTN_SSID1_BUTTON7                                                   76

#define  _BTN_SSID1_BUTTON9                                                   77

#define  _BTN_SSID1_BUTTON10                                                  78

#define  _BTN_SSID1_BUTTON11                                                  79

#define  _BTN_SSID1_BUTTON12                                                  80

#define  _ANIMATION_SSID1_ICON1                                              101

#define  _ANIMATION_SSID1_ICON2                                              111

#define  _ANIMATION_SSID1_ICON3                                              102

#define  _ANIMATION_SSID1_ICON4                                              112

#define  _ANIMATION_SSID1_ICON5                                              103

#define  _ANIMATION_SSID1_ICON6                                              113

#define  _ANIMATION_SSID1_ICON7                                              104

#define  _ANIMATION_SSID1_ICON8                                              114

#define  _ANIMATION_SSID1_ICON9                                              105

#define  _ANIMATION_SSID1_ICON10                                             115

#define  _ANIMATION_SSID1_ICON11                                             106

#define  _ANIMATION_SSID1_ICON12                                             116

#define  _ANIMATION_SSID1_ICON13                                             107

#define  _ANIMATION_SSID1_ICON14                                             117

#define  _ANIMATION_SSID1_ICON15                                             108

#define  _ANIMATION_SSID1_ICON16                                             118

#define  _ANIMATION_SSID1_ICON17                                             109

#define  _ANIMATION_SSID1_ICON18                                             119

#define  _ANIMATION_SSID1_ICON19                                             110

#define  _ANIMATION_SSID1_ICON20                                             120

#define  _TXT_DIS__SSID2_TEXT_DISPLAY1                                        61

#define  _TXT_DIS__SSID2_TEXT_DISPLAY2                                        62

#define  _TXT_DIS__SSID2_TEXT_DISPLAY3                                        63

#define  _TXT_DIS__SSID2_TEXT_DISPLAY4                                        64

#define  _TXT_DIS__SSID2_TEXT_DISPLAY5                                        65

#define  _TXT_DIS__SSID2_TEXT_DISPLAY6                                        66

#define  _TXT_DIS__SSID2_TEXT_DISPLAY7                                        67

#define  _TXT_DIS__SSID2_TEXT_DISPLAY8                                        68

#define  _TXT_DIS__SSID2_TEXT_DISPLAY9                                        70

#define  _TXT_DIS__SSID2_TEXT_DISPLAY10                                       69

#define  _BTN_SSID2_BUTTON1                                                   71

#define  _BTN_SSID2_BUTTON3                                                   72

#define  _BTN_SSID2_BUTTON4                                                   73

#define  _BTN_SSID2_BUTTON5                                                   74

#define  _BTN_SSID2_BUTTON6                                                   75

#define  _BTN_SSID2_BUTTON7                                                   76

#define  _BTN_SSID2_BUTTON9                                                   77

#define  _BTN_SSID2_BUTTON10                                                  78

#define  _BTN_SSID2_BUTTON11                                                  79

#define  _BTN_SSID2_BUTTON12                                                  80

#define  _ANIMATION_SSID2_ICON1                                              101

#define  _ANIMATION_SSID2_ICON2                                              111

#define  _ANIMATION_SSID2_ICON3                                              102

#define  _ANIMATION_SSID2_ICON4                                              112

#define  _ANIMATION_SSID2_ICON5                                              103

#define  _ANIMATION_SSID2_ICON6                                              113

#define  _ANIMATION_SSID2_ICON7                                              104

#define  _ANIMATION_SSID2_ICON8                                              114

#define  _ANIMATION_SSID2_ICON9                                              105

#define  _ANIMATION_SSID2_ICON10                                             115

#define  _ANIMATION_SSID2_ICON11                                             106

#define  _ANIMATION_SSID2_ICON12                                             116

#define  _ANIMATION_SSID2_ICON13                                             107

#define  _ANIMATION_SSID2_ICON14                                             117

#define  _ANIMATION_SSID2_ICON15                                             108

#define  _ANIMATION_SSID2_ICON16                                             118

#define  _ANIMATION_SSID2_ICON17                                             109

#define  _ANIMATION_SSID2_ICON18                                             119

#define  _ANIMATION_SSID2_ICON19                                             110

#define  _ANIMATION_SSID2_ICON20                                             120

//����ProductCenter�ı���ͼƬ
#define  _IMG_PRODUCTCENTER                                                   23

//����ProductCenter�а�ťButton1����ʱ��ͼƬ
#define  _IMG_PRODUCTCENTER_BUTTON1_DOWN                                      36

#define  _BTN_PRODUCTCENTER_BUTTON1                                          100

#define  _PROGRESS_PRODUCTCENTER_PROGRESS1                                   101

#define  _BTN_PRODUCTCENTER_BUTTON2                                          111

//����ProductCenter�а�ťButton3����ʱ��ͼƬ
#define  _IMG_PRODUCTCENTER_BUTTON3_DOWN                                      97

#define  _BTN_PRODUCTCENTER_BUTTON3                                          112

//����ProductCenter�а�ťButton4����ʱ��ͼƬ
#define  _IMG_PRODUCTCENTER_BUTTON4_DOWN                                      97

#define  _BTN_PRODUCTCENTER_BUTTON4                                          113

//����ProductCenter��ͼƬImage4ʹ�õ�ͼƬ
#define  _IMG_PRODUCTCENTER_IMAGE4                                            24

//����ProductCenter�а�ťButton5����ʱ��ͼƬ
#define  _IMG_PRODUCTCENTER_BUTTON5_UP                                        25

//����ProductCenter�а�ťButton5����ʱ��ͼƬ
#define  _IMG_PRODUCTCENTER_BUTTON5_DOWN                                      26

#define  _BTN_PRODUCTCENTER_BUTTON5                                           12

//����ProductCenter�а�ťButton9����ʱ��ͼƬ
#define  _IMG_PRODUCTCENTER_BUTTON9_UP                                        33

#define  _BTN_PRODUCTCENTER_BUTTON9                                           10

#define  _RTC_PRODUCTCENTER_RTC1                                              11

#define  _TXT_DIS__PRODUCTCENTER_TEXT_DISPLAY1                                 2

#define  _BTN_PRODUCTCENTER_BUTTON12                                          15

#define  _BTN_PRODUCTCENTER_BUTTON13                                          16

//����ProductCenter�а�ťButton14����ʱ��ͼƬ
#define  _IMG_PRODUCTCENTER_BUTTON14_UP                                       36

//����ProductCenter�а�ťButton14����ʱ��ͼƬ
#define  _IMG_PRODUCTCENTER_BUTTON14_DOWN                                     96

#define  _BTN_PRODUCTCENTER_BUTTON14                                           3

//����ProductCenter�а�ťButton6����ʱ��ͼƬ
#define  _IMG_PRODUCTCENTER_BUTTON6_UP                                        37

//����ProductCenter�а�ťButton6����ʱ��ͼƬ
#define  _IMG_PRODUCTCENTER_BUTTON6_DOWN                                      38

#define  _BTN_PRODUCTCENTER_BUTTON6                                           26

//����ProductCenter�а�ťButton7����ʱ��ͼƬ
#define  _IMG_PRODUCTCENTER_BUTTON7_UP                                        39

//����ProductCenter�а�ťButton7����ʱ��ͼƬ
#define  _IMG_PRODUCTCENTER_BUTTON7_DOWN                                      40

#define  _BTN_PRODUCTCENTER_BUTTON7                                           23

//����ProductCenter�а�ťButton8����ʱ��ͼƬ
#define  _IMG_PRODUCTCENTER_BUTTON8_UP                                        41

//����ProductCenter�а�ťButton8����ʱ��ͼƬ
#define  _IMG_PRODUCTCENTER_BUTTON8_DOWN                                      42

#define  _BTN_PRODUCTCENTER_BUTTON8                                           31

//����ProductCooper�ı���ͼƬ
#define  _IMG_PRODUCTCOOPER                                                   23

//����ProductCooper��ͼƬImage4ʹ�õ�ͼƬ
#define  _IMG_PRODUCTCOOPER_IMAGE4                                            24

//����ProductCooper�а�ťButton5����ʱ��ͼƬ
#define  _IMG_PRODUCTCOOPER_BUTTON5_UP                                        25

//����ProductCooper�а�ťButton5����ʱ��ͼƬ
#define  _IMG_PRODUCTCOOPER_BUTTON5_DOWN                                      26

#define  _BTN_PRODUCTCOOPER_BUTTON5                                           12

//����ProductCooper�а�ťButton9����ʱ��ͼƬ
#define  _IMG_PRODUCTCOOPER_BUTTON9_UP                                        33

#define  _BTN_PRODUCTCOOPER_BUTTON9                                           10

#define  _RTC_PRODUCTCOOPER_RTC1                                              11

#define  _TXT_DIS__PRODUCTCOOPER_TEXT_DISPLAY1                                 3

#define  _TXT_DIS__PRODUCTCOOPER_TEXT_DISPLAY2                                 6

#define  _TXT_DIS__PRODUCTCOOPER_TEXT_DISPLAY3                                 8

#define  _TXT_DIS__PRODUCTCOOPER_TEXT_DISPLAY4                                13

#define  _BTN_PRODUCTCOOPER_BUTTON1                                           14

#define  _TXT_DIS__PRODUCTCOOPER_TEXT_DISPLAY5                                15

#define  _BTN_PRODUCTCOOPER_BUTTON2                                           16

//����ProductCooper�а�ťButton6����ʱ��ͼƬ
#define  _IMG_PRODUCTCOOPER_BUTTON6_UP                                        37

//����ProductCooper�а�ťButton6����ʱ��ͼƬ
#define  _IMG_PRODUCTCOOPER_BUTTON6_DOWN                                      38

#define  _BTN_PRODUCTCOOPER_BUTTON6                                           26

//����ProductCooper�а�ťButton7����ʱ��ͼƬ
#define  _IMG_PRODUCTCOOPER_BUTTON7_UP                                        39

//����ProductCooper�а�ťButton7����ʱ��ͼƬ
#define  _IMG_PRODUCTCOOPER_BUTTON7_DOWN                                      40

#define  _BTN_PRODUCTCOOPER_BUTTON7                                           23

//����ProductCooper�а�ťButton8����ʱ��ͼƬ
#define  _IMG_PRODUCTCOOPER_BUTTON8_UP                                        41

//����ProductCooper�а�ťButton8����ʱ��ͼƬ
#define  _IMG_PRODUCTCOOPER_BUTTON8_DOWN                                      42

#define  _BTN_PRODUCTCOOPER_BUTTON8                                           31

//����LinkUs�ı���ͼƬ
#define  _IMG_LINKUS                                                          23

//����LinkUs��ͼƬImage4ʹ�õ�ͼƬ
#define  _IMG_LINKUS_IMAGE4                                                   24

//����LinkUs�а�ťButton5����ʱ��ͼƬ
#define  _IMG_LINKUS_BUTTON5_UP                                               25

//����LinkUs�а�ťButton5����ʱ��ͼƬ
#define  _IMG_LINKUS_BUTTON5_DOWN                                             26

#define  _BTN_LINKUS_BUTTON5                                                  12

//����LinkUs�а�ťButton9����ʱ��ͼƬ
#define  _IMG_LINKUS_BUTTON9_UP                                               33

#define  _BTN_LINKUS_BUTTON9                                                  10

#define  _RTC_LINKUS_RTC1                                                     11

#define  _QCODE_LINKUS_QRCODE1                                                 8

//����LinkUs�а�ťButton4����ʱ��ͼƬ
#define  _IMG_LINKUS_BUTTON4_UP                                               37

//����LinkUs�а�ťButton4����ʱ��ͼƬ
#define  _IMG_LINKUS_BUTTON4_DOWN                                             38

#define  _BTN_LINKUS_BUTTON4                                                  26

//����LinkUs�а�ťButton1����ʱ��ͼƬ
#define  _IMG_LINKUS_BUTTON1_UP                                               39

//����LinkUs�а�ťButton1����ʱ��ͼƬ
#define  _IMG_LINKUS_BUTTON1_DOWN                                             40

#define  _BTN_LINKUS_BUTTON1                                                  23

//����LinkUs�а�ťButton6����ʱ��ͼƬ
#define  _IMG_LINKUS_BUTTON6_UP                                               41

//����LinkUs�а�ťButton6����ʱ��ͼƬ
#define  _IMG_LINKUS_BUTTON6_DOWN                                             42

#define  _BTN_LINKUS_BUTTON6                                                  31

