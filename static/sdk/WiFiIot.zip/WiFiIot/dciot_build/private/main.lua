--*****************************************************************--
--=================================================================--
--							iqkit开发简介							--
--1. 云端注册账号，创建产品，定义功能								  --
--2. 将创建的产品所生成的Key填入product_key							 --
--3. 将功能定义参数填入device_function，包含关联控件ID和触发器信息	   --
--4. 将设备通信协议配置信息填入device_protocol_config				 --
--5. 编辑界面，根据配置的控件ID，一一对应设置正确					   --
--6. 扩展页面逻辑处理请在on_function_state_change方法中实现			  --
--7. 联调测试														--
--补充说明：目前界面的自动联动效果只限于开关类型功能，后续将继续扩展     --
--		   后续将实现功能定义和协议定义的自动化导入，无需再手动配置		--
--																   --
--											Zhujian 2018/07/05	   --
--=================================================================--
--*****************************************************************--

uart_free_protocol = 1
---------------Control ID Rule--------------------------------------------------------------
--	1~20: 保留功能按键，1：电源，2：锁屏，3：Home，4：返回，5：帮助，6：二维码，7：音量，8：亮度...
--	21~50：系统状态指示，21：标题，22：当前时间，23：WiFi
--	51~100：设备状态指示
--	101~200：用于共用控件，x1：上一个，x2：下一个，x3：第一个，x4：最后一个，x5：目标选择或图标控件
--	201~300：背景及静态控件
--	300以上：动态交互控件
--[[系统定时器分配
	0: 休眠管理
	1: 延迟定时获取Mac地址
	2: 延迟扫描AP
	3: 等待对话框超时处理
	4: 延迟定时获取API Token

	10: 通信心跳
	11: 命令重发
	12：工作倒计时
--]]
--------------------------------------------------------------------------------------------
local control_id_rule=0		--是否启用上述控件ID规则，ID在设置值以内的控件将自动处理功能逻辑
local event_bus={}
local product_key_packet={}
local mac_string=""
local mac_packet={}
local configuration_file_path
local configuration={
	language=2,
	backlight=80,
	server_address='suite.53iq.com',	--'suite.53iq.com'  --"192.168.191.1"	--"122.144.167.71"
	server_port=2502,
	remote_control_enable=1,	--是否允许远程控制
	ui_log_enable=0,	--界面上日志打印开关
	power_manage_enable=1,	--是否自动休眠或熄屏
	low_power=1,	--低功耗休眠还是熄屏
	sync_server_time=1,	--自动同步服务器时间
	auto_sleep_delay=180000,	--自动休眠或熄屏时间
	loading_timeout=3000,
	unlock_timeout=3000
}

local dialog_deal_function	--对话框关闭处理方法
local loadding_is_modal=true	--等待对话框是模态
local loading_timeout=3000	--默认加载超时时间
local unlock_timeout=3000	--解锁长按时间
local unlock_time=0	--解锁长按累计时间
local upgrade_state=0	--升级状态
local lock_state=0	--锁屏状态,0未锁，1已解锁

local api_token=nil
local net_connect_status=0	--bit0:无线网络连接,bit1:有线网络连接,bit2:是否连接到服务器,bit3：是否有客户端连接上
local server_connect_status=0	--0:未连接  1：连接中  2:已连接
--通信相关全局变量
local serialnum_net=0
local serialnum_dev=0
local uart_recv_data={}	--串口数据接收缓冲区
local needChecksum=1	--是否校验通信数据
local net_endian_type=1	--数据大小端编码类型，0：小端，1：大端
local selected_model=0

local product_model='DC80480W050'
local selected_product=0

---------------------------产品相关配置开始---------------------------
local version_code=2018080301
local version_name='1.1.4'
--多语言配置
local languages={
	[0]={
		NeedConnectWiFi="Please connect to the network first",
		Upgrade="Upgrade",
		UpgradeTip="New version found:%s, upgrade?",
		LatestVersionTip="Is already the latest version",
		StopWork="Stop Work",
		StopWorkTip="Confirm Stop Working?",
		SmartHelp="Smart Help",
		MessageSendingTip="Related message is sending...",
		MessageSendSuccessTip="Message sent to Smart Kitchen app",
		MessageSendFailTip="Message sent failed",
		NeedBindDeviceTip="Please scan the top left two-dimensional code, download app, bind device",
		Delete="Delete",
		DeleteConfirmTip="Are you sure you would delete this item?",
		Register="Register",
		Repair="Repair",
		Favorite="Collection",
		FavoriteSuccess="Collection successful"
	},
	{
		NeedConnectWiFi="لطفا اتصال به شبکه اول",
		Upgrade="ارتقاء",
		UpgradeTip="نسخه جدید یافت: %s ارتقاء داده شده است؟",
		LatestVersionTip="در حال حاضر آخرین نسخه است",
		StopWork="توقف کار",
		StopWorkTip="تایید توقف کار?",
		SmartHelp="کمک های هوشمند",
		MessageSendingTip="اطلاعات مربوط به ارسال شد...",
		MessageSendSuccessTip="اطلاعات به نرم افزار هوشمند آشپزخانه فرستاده شده",
		MessageSendFailTip="اطلاعات ارسال ناموفق",
		NeedBindDeviceTip="لطفا بالا سمت چپ کد دو بعدی اسکن, دانلود نرم افزار, اتصال دستگاه",
		Delete="حذف",
		DeleteConfirmTip="شما این مورد را حذف می شود؟",
		Register="ثبت نام",
		Repair="تعمیر",
		Favorite="مجموعه",
		FavoriteSuccess="مجموعه موفق"
	},
	{
		NeedConnectWiFi="请先连接网络",
		Upgrade="升级",
		UpgradeTip="发现新版本:%s, 是否升级?",
		LatestVersionTip="已经是最新版本",
		StopWork="停止工作",
		StopWorkTip="是否确认停止工作？",
		SmartHelp="智能帮助",
		MessageSendingTip="相关信息正在发送...",
		MessageSendSuccessTip="信息已发送至智能厨房App",
		MessageSendFailTip="信息发送失败",
		NeedBindDeviceTip="请先扫描屏幕左上角二维码，下载智能厨房App，绑定设备",
		Delete="删除",
		DeleteConfirmTip="确定删除该项？",
		Register="注册",
		Repair="报修",
		Favorite="收藏",
		FavoriteSuccess="收藏成功"
	}
}
local page_mapping={[0]="Main", "Setting","WiFi","Qrcode","Dialog","Loading","WiFiConfig","Lock","SSID1","SSID2", "ProductCenter", "ProductCooper", "Linkus"}
local page_name_mapping={[0]="首页", "设置","WiFi","二维码","对话框","等待","WiFi配置","锁屏","热点列表1","热点列表2","产品中心","产品合作","联系我们"}
local page_visitor={}
local last_screen=-1	--上一个打开的画面，返回的情况下和访问堆栈中的前一个不是同一个，因此单独记录

---------------事件处理机制开始-------------------
function GetEvent(category, id)
	if event_bus[category]~=nil then
		if id~=nil then
			return event_bus[category][id]
		else
			return event_bus[category]
		end
	end
end
function BindEvent(category, fn, id)
	if event_bus[category]==nil then
		event_bus[category]={}
	end
	if id~=nil then
		event_bus[category][id]=fn
	else
		local fn_exist=false
		for k,v in ipairs(event_bus[category]) do
			if v==fn then
				fn_exist=true
				break
			end
		end
		if fn_exist==false then
			table.insert(event_bus[category],fn)
		end
	end
end
function UnbindEvent(category, fn, id)
	local events=GetEvent(category)
	if id~=nil then
		if events[id]~=nil then
			table.remove(events, id)
		end
	else
		for k,v in ipairs(events) do
			if v==fn then
				table.remove(events, k)
			end
		end
	end
end
function RaiseEvent(category, ...)
	local events=GetEvent(category)
	if events~=nil then
		for k,v in ipairs(events) do
			v(...)
		end
	end
end
---------------事件处理机制结束-------------------

local device_type=1
--**填写该设备在云端注册分配的产品型号Key
-- start product_key config
local product_key="NtWFp3VZ"
-- end product_key config
--设备功能定义及虚拟设备状态，协议定义中数据域部分的功能应全部定义在该项内
--虚拟功能也可定义在该对象中，用于状态的统一管理，但应注意不要定义length属性，即没有length属性的功能项不会被生成到命令数据中
-- start device_function config
local device_function={
	{name="Fan3", length=1, title="大风", controls={Main=113}, triggers={
		[1]={Power=1, Fan1=0, Fan2=0}
	}},
	{name="Fan2", length=1, title="中风", controls={Main=112}, triggers={
		[1]={Power=1, Fan1=0, Fan3=0}
	}},
	{name="Fan1", length=1, title="小风", controls={Main=111}, triggers={
		[1]={Power=1, Fan2=0, Fan3=0}
	}},
	{name="Wash", length=1, title="清洗"},
	{name="Light", length=1, title="照明", controls={Main=102}, triggers={
		[1]={Power=1}
	}},
	{name="Down", length=1, title="降"},
	{name="Up", length=1, title="升"},
	{name="Lamp", length=1, title="Lamp"},

	{name="Power", length=1, title="电源", value=1, controls={Main=101}, triggers={
		[0]={All=0},
		[1]={Fan2=1}
	}},
	{name="Fire", length=1, title="火焰信号"},
	{name="LeftGas", length=1, title="左灶"},
	{name="Beep", length=2, title="蜂鸣"},
	{name="Dry", length=1, title="烘干", controls={114}, triggers={
		[1]={Power=1, Disinfectants=0}
	}},
	{name="Disinfectants", length=1, title="消毒", controls=115, triggers={
		[1]={Power=1, Dry=0}
	}},
	{name="Aux", length=1, title="Aux"},
	
	{name="Temp", length=8, title="烟道温度", controls=110},
	{name="Fault", length=8, title="故障报警"}
}
-- end device_function config
--标准通信协议配置，请勿更改
--如需使用私有协议，请用同样的数据结构分别配置device_protocol_config和device_protocol_response_config
local protocol_config={	
	endian_type=1,		--大小端编码规则,0：小端，1：大端
	check_type='sum',	--校验算法,sum,crc16...
	length_offset=6,	--长度相对于整帧长度的偏移值，即length+length_offset=整帧长度
	check_data_start=0,	--校验起始位置，0开始
	check_data_end=-1,	--校验数据结束位置，正数：第几个字节，0：末尾，负数：整帧末尾往前几个字节,包含校验数据本身

	--帧结构描述，值为所占字节长度，请根据自己的协议对值和顺序进行调整
	structs={	--上行指令特殊部分重定义
		{name="head", value={0xA5, 0x5A}},
		{name="serial", length=1},
		{name="command", length=1},
		{name="length", length=1},
		{name="data", value=device_function},
		{name="check", length=1}
	}
}
--上行帧配置，和标准协议配置中相同的部分可不配
local protocol_response_config={
	structs={	--上行指令特殊部分重定义
		{name="head", value={0x5A, 0xA5}},
		{name="serial", length=1},
		{name="command", length=1},
		{name="length", length=1},
		{name="response", value=0x00},
		{name="data", value=device_function},
		{name="check", length=1}
	}
}
--------------------------产品相关配置结束--------------------------

------------------------电控协议处理部分开始-----------------------
---该部分目前是按53iq标准蒸烤箱电控协议为模板的实现
---请根据自己的电控协议酌情修改实现对接
-----------------------------------------------------------------

--------------------------私有协议配置开始--------------------------
--**私有协议配置,格式和标准协议格式保持一致
--如过上行应答协议格式和下行命令协议格式不一致，请单独配置下面的 protocol_response_config，否则不要配置 protocol_response_config
-- start device_protocol_config config
local device_protocol_config={	
	endian_type=0,		--大小端编码规则,0：小端，1：大端

	length=9,			--帧长，变长填nil,同时指定长度所在的字节范围索引，length_start, length_end
	length_offset=nil,	--长度相对于整帧长度的偏移值，即length+length_offset=整帧长度

	check_type='crc16',	--校验算法,sum,crc16...
	check_data_start=0,	--校验数据起始位置，0开始
	check_data_end=-2,	--校验数据结束位置，正数：第几个字节，0：末尾，负数：末尾往前几个字节,包含校验数据本身
	
	--帧结构描述，主要用于指令的生成，设置该项后，协议解析库会将数据分别解析设置到各个字段中
	--其中Data数据域部分定义和云端定义的虚拟设备不一致，请在此处重写定义
	structs={	
		{name='head', length=1, value={0xA5}},
		{name="version", length=1, value={0x01}},
		{name="category", length=1, value={0x01}},
		{name='data', length=4},
		{name='check', length=2}
	}
}
-- end device_protocol_config config
--上行应答协议格式配置，和标准协议配置中相同的部分可不配
local device_protocol_response_config
--------------------------私有协议配置结束--------------------------

--------------------------状态改变事件处理开始--------------------------
---**云端指令或电控上报导致设备功能项状态变更事件处理，主要用于UI的联动处理
----------------------------------------------------------------------
BindEvent('on_function_state_change', function (item)
	--print('Raise Event: on_function_state_change, name: '..item.name..' value: '..item.value)
	local work_screen=GetScreenID('Work')
	if item.name=="Lock" then
		if item.value==1 then
			ShowLock()
		elseif item.last_value==1 then
			CloseLock()
		end
	end
end)
--------------------------状态改变事件处理结束--------------------------

--------------------------通信协议解析库开始----------------------------
--获取上下行对应的协议配置信息，并初始化(协议结构数据所表示的值、起始位置、结束位置等属性)
--direct: 1为应答帧信息，否则为命令帧结构信息
--device: 1为设备通信端协议，否则为云端通信协议
function GetProtocol(direct, device)
	init = function(protocol)
		if protocol~=nil and protocol.init==nil then
			if protocol==protocol_response_config then
				for k,v in pairs(protocol_config) do
					if protocol[k]==nil then
						protocol[k]=v
					end
				end
			elseif protocol==protocol_response_config then
				for k,v in pairs(device_protocol_config) do
					if protocol[k]==nil then
						protocol[k]=v
					end
				end
			end
			local start_index=0
			local structs=protocol.structs
			for k,v in ipairs(structs) do
				local name=v.name
				if v.length==nil and v.value~=nil then
					if name~='data' then
						if type(v.value)=='table' then
							v.length=#v.value
						else
							v.length=1
						end
					else
						local len=0
						for i,j in pairs(v.value) do
							len=len+j.length
						end
						v.length=math.ceil(len/8)
					end
				end
				protocol[name..'_start']=start_index
				protocol[name..'_end']=start_index+v.length-1
				if v.value~=nil then
					protocol[name]=v.value
				end
				start_index=start_index+v.length
			end
			if protocol.length==nil and protocol.length_offset==nil then
				protocol.length=start_index
			end
			protocol.init=true
		end
	end
	init(protocol_config)
	init(protocol_response_config)
	if device_protocol_config~=nil then
		init(device_protocol_config)
	end
	if device_protocol_response_config~=nil then
		init(device_protocol_response_config)
	end

	if direct~=nil and direct>0 then
		if device~=nil and device>0 then
			if device_protocol_response_config~=nil then
				return device_protocol_response_config
			elseif  device_protocol_config~=nil then
				return device_protocol_config
			end
		else
			if protocol_response_config~=nil then
				return protocol_response_config
			end
		end
	else
		if device~=nil and device>0 then
			if device_protocol_config~=nil then
				return device_protocol_config
			end
		end
	end
	return protocol_config
end
---------------------------------------------------
--协议数据域组合功能解析方法
--解析并映射至虚拟设备功能状态中，同时触发UI配置
-------------------------------------------------
function AnalyzeCombFunctionData(data, start, len)
	if start==nil then
		start=0
	end
	if len==nil or len>#data then
		len=#data
	end
	local state_changed=false
	local i=start
	while(i<start+len) do
		item=device_function[data[i]]
		if item~=nil then
			local byte_len=math.ceil(item.length/8)
			item.value=0
			for j=1,byte_len do
				if net_endian_type==1 then
					item.value = item.value+data[i+byte_len+1-j] * 256^(j-1)
				else
					item.value = item.value+data[i+j] * 256^(j-1)
				end
			end
			i=i+byte_len+1
			if item.value~=item.last_value then
				state_changed=true
				--TLog(string.format("%s: 0x%X", v.title, v.value))
			end
			on_function_state_change(item)
			item.last_value=item.value
		else
			return
		end
	end
	return state_changed
end
---------------------------------------------------
--协议数据域全功能解析方法
--解析并映射至虚拟设备功能状态中，同时触发UI配置
-------------------------------------------------
function AnalyzeFunctionData(data, start, template)
	if template==nil then
		template=device_function
	end
	local state_changed=false
	local bit_sum=0
	local byte_index=0
	local bit_index=0
	for k,v in ipairs(template) do
		if v.length~=nil and v.length>0 then
			local _data={}
			bit_index=bit_sum % 8 + 1
			byte_index=math.floor(bit_sum/8)
			bit_sum=bit_sum+v.length
			local data_byte_end=math.ceil(bit_sum/8)-1
			for i=byte_index,data_byte_end do
				_data[i-byte_index]=data[start+i]
			end
			v.last_value=v.value
			if bit_index > 0 and #_data == 0 then
				local left_len = bit_index-1
				local right_len = 8 - v.length
				v.value=((_data[0] << left_len) & 0xFF) >> right_len
			else
				v.value = 0
				for i=0,#_data do
					v.value = v.value+_data[i] * 256^(#_data-i)
				end
			end
			if v.value~=v.last_value then
				if template~=device_function then
					local item=GetFunctionItem(v.name)
					if item~=nil then
						item.last_value=item.value
						item.value=v.value
						item.value_repeat=0
						on_function_state_change(item)
						if item.length~=nil and item.length>0 then
							state_changed=true
						end
					end
				else
					on_function_state_change(v)
					state_changed=true
				end
				--TLog(string.format("%s: 0x%X", v.title, v.value))
				v.value_repeat=0
			else
				if v.value_repeat==nil then
					v.value_repeat=0
				end
				v.value_repeat=v.value_repeat+1
				if template~=device_function then
					local item=GetFunctionItem(v.name)
					if item~=nil then
						item.value_repeat=item.value_repeat+1
					end
				end
			end
			on_function_state_set(v)
		end
	end
	on_function_state_analyzed(state_changed)
	return state_changed
end
--------------------------------------------------
--协议数据帧解析方法
--接收数据并检测，当得到有效数据帧格式时触发数据域解析方法
-------------------------------------------------
function ProcessProtocolData(data, protocol)
	-- 相同数据不做解析
	-- if uart_recv_data~=nil and packet~=nil and #uart_recv_data==#packet 
	-- 	and table.equals(packet, uart_recv_data) then
	-- 	return
	-- end
	print("Uart Recv:"..BytesToHexString(data))

	--[[
	local len = #uart_recv_data
	if len>0 then
		len=len+1
	end
	for i=0,#packet do
		if table.equals(protocol.head, packet, i) and #uart_recv_data > 0 then
			uart_recv_data = {}
			len=i*-1-1
		end
		uart_recv_data[i+len] = packet[i]
	end
	TLog(string.format("RU: %d-%d-%d", serialnum_dev, #packet, #uart_recv_data))
	TLog("Recv:"..BytesToHexString(packet))
	TLog("R:"..BytesToHexString(uart_recv_data))
	--]]

	uart_recv_data=data

	--字头判断
	if table.equals(protocol.head, uart_recv_data)==false then
		return
	end
	--帧长判断
	local frame_length=0
	if protocol.length~=nil and protocol.length>0 then	--定长
		frame_length=protocol.length-1
		if #uart_recv_data~=frame_length then
			return
		end
	else	--变长
		local length_offset=0
		if protocol.length_offset~=nil then
			length_offset=protocol.length_offset
		end
		local len=BytesToInt(uart_recv_data,protocol.length_start,protocol.length_end)
		frame_length=len+length_offset-1
		if #uart_recv_data~=frame_length then
			return
		end
	end
	--校验判断
	local check_value=BytesToInt(uart_recv_data, protocol.check_start, protocol.check_end)
	local check_result=0
	local check_data_end=protocol.check_data_end
	if check_data_end<=0 then
		check_data_end=frame_length+check_data_end
	end
	if protocol.check_type=='crc16' then
		check_result=CRC16(uart_recv_data,protocol.check_data_start,check_data_end)
	elseif protocol.check_type=='sum' then
		check_result=CheckSum(uart_recv_data,protocol.check_data_start,check_data_end)
	else

	end
	if check_value~=check_result then
		return
	end
	return AnalyzeFunctionData(data, protocol.data_start, protocol.data)
end
-------------------------------------------------
--数据域数据获取方法
--从虚拟设备状态值中组合数据对应协议的数据域数据
-------------------------------------------------
function GetFunctionData(template)
	if template==nil then
		template=device_function
	end
	local bit_sum=0
	local byte_index=0
	local bit_index=0
	local _data={}
	for k,v in ipairs(template) do
		if v.length~=nil and v.length>0 then
			bit_index=bit_sum % 8 + 1
			byte_index=math.floor(bit_sum/8)
			bit_sum=bit_sum+v.length
			local data_byte_end=math.ceil(bit_sum/8)-1
			local val=_data[byte_index]
			if val==nil then
				val=0x00
			end
			local value=v.value
			if template~=device_function then
				value=GetFunctionValue(v.name)
			end
			if value==nil then
				value=0x00
			end
			if v.length<8 then
				val=val | (value << (8 - bit_index - v.length + 1))
				_data[byte_index] = val
			else
				local num=math.ceil(v.length/8)
				for i=1, num do
					_data[byte_index+i-1]=(value&(256^(num-i+1)-1))>>(num-i)*8
				end
			end
		end
	end
	return _data
end
-------------------------------------------------
--获取协议数据帧方法
-------------------------------------------------
function GetProtocolData(protocol)
	local data={}
	local frame_index=0
	for k,v in ipairs(protocol.structs) do
		local _data=v.value
		if v.name=='data' then
			_data=GetFunctionData(protocol.data)
		elseif v.name=='check' then
			
		elseif v.name=='length' then

		elseif v.name=='serial' then
			if v.value==nil or BytesToInt(v.value)>=2^(v.length*8) then
				v.value=IntToBytes(0, protocol.endian_type, v.length)
			else
				v.value=IntToBytes(BytesToInt(v.value)+1, protocol.endian_type, v.length)
			end
			_data=v.value
		elseif v.name=='type' then

		end
		if _data==nil then
			_data={}
		end
		if type(_data)=='table' then
			if #_data<v.length then
				for i=#_data+1,v.length do
					_data[i]=0x00
				end
			end
			local start=table.getstart(_data)
			for i=start,#_data do
				data[frame_index+i-start]=_data[i]
			end
		else
			data[frame_index]=_data
		end
		frame_index=frame_index+v.length
	end
	--变长修正
	if protocol.length_offset~=nil then
		local len_data=IntToBytes(#data)
		for i=1,#len_data do
			data[protocol.length_end-i+1]=len_data[#len_data-i+1]
		end
	end
	--校验
	local check_data
	local check_data_end=protocol.check_data_end
	if check_data_end<=0 then
		check_data_end=#data+check_data_end
	end
	if protocol.check_type=='crc16' then
		check_data=IntToBytes(CRC16(data, protocol.check_data_start, check_data_end))
	elseif protocol.check_type=='sum' then
		check_data=IntToBytes(CheckSum(data, protocol.check_data_start, check_data_end))
	end
	for i=1,#check_data do
		data[protocol.check_end-i+1]=check_data[#check_data-i+1]
	end
	return data
end
--对接私有电控协议需要重写的方法，该方法主要实现通信帧的有效性识别
function ProcessUartCommand(packet)
	local protocol=GetProtocol(1,1)
	if ProcessProtocolData(packet, protocol) then
		SendCloudCommand()
	end
end
--生成目标电控控制指令
function GetDeviceCommand(beep, beep_name)
	if beep_name==nil then
		beep_name='Beep'
	end
	if beep==nil then
		beep=1
	end
	local beep_item=GetFunctionItem(beep_name)
	if beep_item~=nil then
		-- if beep_item.length>1 then
		-- 	if beep_item.value==1 then
		-- 		beep_item.value=2
		-- 	else
		-- 		beep_item.value=1
		-- 	end
		-- else
		-- 	beep_item.value=1
		-- end
		beep_item.value=beep
	end
	local protocol=GetProtocol(0,1)
	local data=GetProtocolData(protocol)
	if beep_item~=nil then
		beep_item.value=0
	end
	return data
end

---云端指令或电控上报导致设备功能项状态变更事件处理，主要用于UI的联动处理
function on_function_state_change(item)
	if item~=nil then
		if item.controls~=nil then
			local screen=0
			local value=item.value
			if item.format~=nil then
				value=eval(item.format..'('..item.value..')')
				if value==nil then
					value=0
				end
			end
			if type(item.controls)=='table' then
				for p,c in pairs(item.controls) do
					if type(p)=='string' then
						screen=GetScreenID(p)
					elseif page_visitor[#page_visitor]~=nil then
						screen=page_visitor[#page_visitor]
					end
					--print(item.name..' function state change update '..screen..' control '..c..' value '..value..'('..item.value..')')
					if type(value)=='string' then
						set_text(screen,c,value)
					else
						set_value(screen,c,value)
					end
				end
			else
				if page_visitor[#page_visitor]~=nil then
					screen=page_visitor[#page_visitor]
				end
				--print(item.name..' function state change update '..screen..' control '..item.controls..' value '..value..'('..item.value..')')
				if type(value)=='string' then
					set_text(screen,item.controls,value)
				else
					set_value(screen,item.controls,value)
				end
			end
		end
		RaiseEvent('on_function_state_change', item)
	end
end
function on_function_state_set(item)

end
function on_function_state_analyzed()

end
function SendDeviceCommand(command_type)
	UartSendData(GetDeviceCommand(command_type))
end
--云端指令执行成功事件处理，需要生成电控对应的控制协议并下发
function on_clound_command_processed(data)
	SendDeviceCommand()	--发送电控控制指令
end
--云端设备状态查询事件
function on_device_state_query()
	SendDeviceCommand(0xFF)	--发送电控查询指令
end

function UartSendData(data)
	uart_send_data(data)
	local data_string=BytesToHexString(data)
	TLog('Uart Send:'..data_string)
end
function on_client_recv_data(packet)
	ProcessNetCommand(packet)
end
function on_uart_recv_data(packet)
	ProcessUartCommand(packet)
end
------------------------电控协议处理部分结束-----------------------
-----------------------------------------------------------------

----------------------UI和控制协议关联部分开始---------------------
---UI操作控制功能后调用SendFunctionValues方法进行控制和上报,通常不需要修改
-----------------------------------------------------------------
function GetFunctionItem(name)
	for k,v in ipairs(device_function) do
		if v['name']==name then
			return v
		end
	end
end
function GetFunctionValue(name)
	local item=GetFunctionItem(name)
	if item~=nil then
		return item.value
	end
end

function SetFunctionItemValue(item, value)
	local change=false
	if item.value~=value then
		item.last_value=item.value
		item.value=value
		on_function_state_change(item)
		change=true
	end
	return change
end

function SetFunctionValues(items)
	local change=false
	for k,v in pairs(items) do
		if k=='All' then
			for d,i in ipairs(device_function) do
				change=SetFunctionItemValue(i,v) or change
			end
		else
			local i=GetFunctionItem(k)
			if i~=nil and i.value~=v then
				change=SetFunctionItemValue(i,v) or change
			end
		end
	end
	return change
end
function SetFunctionValue(name, val)
	local status={}
	status[name]=val
	SetFunctionValues(status)
end

function OperateFunctionValues(screen, control, value)
	local change=false
	for k,v in ipairs(device_function) do
		if v.controls~=nil then
			if type(v.controls)=='table' then
				for p,c in pairs(v.controls) do
					if c==control and (GetScreenID(p)==screen or type(p)~='string') then
						if v.value~=value then
							v.last_value=v.value
							v.value=value
							change=true
							--print('Function value changed by ui, name:'..v.name..' value:'..v.value)
							on_function_state_change(v)
							if v.triggers~=nil and v.triggers[value]~=nil then
								change=SetFunctionValues(v.triggers[value]) or change
							end
						end
					end
				end
			else
				if v.controls==control then
					if v.value~=value then
						v.last_value=v.value
						v.value=value
						change=true
						on_function_state_change(v)
						if v.triggers~=nil and v.triggers[value]~=nil then
							change=SetFunctionValues(v.triggers[value]) or change
						end
					end
				end
			end
		end
	end
	if change==true then
		SendDeviceCommand()
		SendCloudCommand()
	end
end

--UI操作更新设备功能状态，同事下发电控和上报云端
function SendFunctionValues(items)
	if SetFunctionValues(items)==true then
		SendDeviceCommand()
		SendCloudCommand()
	end
end
function SendFunctionValue(name, val)
	local status={}
	status[name]=val
	SendFunctionValues(status)
end
function ChangeFunctionSwitch(name)
	local val=GetFunctionValue(name)
	if val==1 then
		val=0
	else
		val=1
	end
	SendFunctionValue(name, val)
	return val
end
----------------------UI和控制协议关联部分结束---------------------
-----------------------------------------------------------------

--------------------53iq平台标准协议处理部分开始-------------------
---该部分目前是对接53iq平台标准协议部分，通常不需要修改
---实现全指令和组合指令的解析
---实现虚拟设备的状态机管理
---实现从虚拟设备生成53iq平台标准协议的控制或应答指令
-----------------------------------------------------------------
function GetCloudCommand(command_type)
	local protocol=GetProtocol()
	if command_type==nil then
		protocol.command=0
	else
		protocol.command=command_type
	end
	if protocol.serial==nil or protocol.serial>255 then
		protocol.serial=0
	else
		protocol.serial=protocol.serial+1
	end
	return GetProtocolData(protocol)
end
function SendCloudCommand(command_type)
	ClientSendData(GetCloudCommand(command_type))
end
function ResponseCloudCommand(serialnum, command_type)
	if command_type==0x01 then	--握手帧应答
		server_connect_status=2
		local data = {[0]=0x5A,0xA5,serialnum,command_type,0x17}
		data[5]=0x00	--结果码
		data[6]=0x00
		data[7]=0x01	--版本号
		for i=0,#mac_packet do
			data[i+8]=mac_packet[i]
		end
		for i=0,#product_key_packet do
			data[i+20]=product_key_packet[i]
		end
		data[4] = #data-4;	--长度
		data[#data+1] = CheckSumAll(data)
		ClientSendData(data)
	else
		local protocol=GetProtocol(1)
		if serialnum==nil then
			serialnum=serialnum_net
		end
		protocol.serial=serialnum
		if command_type==nil then
			command_type=0x20
		end
		protocol.command=command_type
		ClientSendData(GetProtocolData(protocol))
	end
end

function ClientSendData(data)
	local data_string=BytesToHexString(data)
	if server_connect_status==2 then
		client_send_data(data)
		TLog('Net Send:'..data_string)
	else
		TLog('Disconnect('..server_connect_status..') Net Send:'..data_string)
	end
end

function ProcessNetCommand(packet)
	--TLog("packet length: "..#packet)
	print('Net Recv:'..BytesToHexString(packet))
	local length_index=table.getstart(packet)+4
	if #packet > length_index and #packet>packet[length_index]+length_index then
		local protocol=GetProtocol()
		if table.equals(protocol.head, packet) then
			serialnum_net=packet[table.getstart(packet)+2]
			local command_type=packet[table.getstart(packet)+3]
			--TLog("Order Command Type: 0x"..string.format("%X", command_type))
			if command_type==0x20 then	--查询
				on_device_state_query()
			elseif configuration~=nil and configuration['remote_control_enable']==1 then	--远程控制
				local state_changed=false
				if command_type==0x21 then	--全指令控制帧
					state_changed=ProcessProtocolData(packet, protocol)
				elseif command_type==0x31 then	--组合指令控制帧
					local command_len=packet[length_index]
					state_changed=AnalyzeCombFunctionData(packet,protocol.data_start,command_len-1)
				end
				if state_changed then
					on_clound_command_processed(packet)
				end
			end
			ResponseCloudCommand(serialnum_net,command_type)
		else
			local protocol_response=GetProtocol(1)
			if table.equals(protocol.head, protocol_response) then
				--TLog("Response Command Type: 0x"..string.format("%X", command_type))
			end
		end
	end
end
--------------------53iq平台标准协议处理部分结束-------------------
-----------------------------------------------------------------

function eval(equation, variables)
    if(type(equation) == "string") then
        local eval = load("return "..equation);
        if(type(eval) == "function") then
            --setfenv(eval, variables or {});
            return eval();
        end
    end
end
--获取路径  
function StripFileName(path)  
    return string.match(path, "(.+)/[^/]*%.%w+$") --*nix system  
    --return string.match(filename, “(.+)\\[^\\]*%.%w+$”) — windows  
end  
  
--获取文件名  
function StripPath(path)  
    return string.match(path, ".+/([^/]*%.[^.]+)$") -- *nix system  
    --return string.match(filename, “.+\\([^\\]*%.%w+)$”) — *windows system  
end
--get filename
function GetFileName(name)
	if StripPath(name)~=nil then
		name=StripPath(name)
	end
    local idx = name:match(".+()%.%w+")
    if(idx) then
        return name:sub(1, idx-1)
    else
        return name  
    end
end
--get file postfix  
function GetExtension(name)  
    return name:match(".+%.(%w+)")
end
function ls(rootpath, deep)
	local ls_result=''
	list_dir=function(rootpath, deep)
		if deep==nil then
			deep=0
		end
		if deep==0 then
			ls_result=rootpath..'\r\n'
		end
		if os.exists(rootpath) then
			for entry in lfs.dir(rootpath) do
				if entry ~= '.' and entry ~= '..' then  
					local path = rootpath .. '/' .. entry  
					--print(path)
					local attr = lfs.attributes(path)  
					local filename = entry	--GetFileName(entry)  
					for i=0,deep do
						ls_result=ls_result..'\t'
					end
					if attr.mode ~= 'directory' then  
						local postfix = GetExtension(entry)
						local file_info=filename..'\t'..attr.size .. '\t' .. attr.mode .. '\t' .. postfix..'\r\n'
						ls_result=ls_result..file_info
					else
						local directory_info=filename .. '\t' .. attr.mode..'\r\n'
						ls_result=ls_result..directory_info
						list_dir(path, deep+1)
					end
				end
			end
		end
		return ls_result
	end
	list_dir(rootpath, deep)
	print(ls_result)
	return ls_result
end
function os.exists(path)
	--[[
	local file,err = io.open(path, "rb")
	if file then file:close() end
	return file ~= nil
	--]]
	return lfs.attributes(path)~=nil
end
function CreateDirectory(path)
	if path~=nil then
		path=StripFileName(path)
		if os.exists(path)==false then
			lfs.mkdir(path)
		end
	end
end
function GetScreenID(name)
	local sid=page_visitor[#page_visitor]
	if name~=nil and page_mapping[sid]~=name then
		for i=0,#page_mapping do
			if page_mapping[i]==name then
				return i
			end
		end
	end
	return sid
end
function GetScreenName(id)
	return page_mapping[id],page_name_mapping[id]
end
function ChangeScreen(name)
	change_screen(GetScreenID(name))
end
function GetReferScreenID()
	if #page_visitor>1 then
		local cid=page_visitor[#page_visitor]
		if cid==GetScreenID('Dialog') or cid==GetScreenID('Lock') 
			or cid==GetScreenID('Loading') then
			return page_visitor[#page_visitor-1]
		end
	end
	return -1
end

function ReadFile(path)
	if os.exists(path) then
		local file=io.input(path)  --当前目录"1.txt"要存在，不然出错
		local str=io.read("*a")
		io.close(file)
		print('Read '..path..': '..str)
		return str
	end
end
function WriteFile(path, content, append)
	local _path=StripFileName(path)
	print('write dir path: '.._path)
	if os.exists(_path)==false then
		os.mkdir(_path)
	end
	local mode='w+'
	if append==true then
		mode='a+'
	end
	local file=io.open(path,mode)
	--file=io.input(path) 
	file:write(content)
	file:flush()
	--file:seek("end",-1) --定位到文件末尾前一个字节
	--content=file:read(1) --读取一个字符
	print('Write '..path..': '..content)
	file:close()
end
function os.mkdir(path)
	local path_tb={}
	local new_path=""
	-- 分割路径保存到table
	for s in string.gmatch(path,"([^'/']+)") do
		if s~=nil then
			table.insert(path_tb,s)
		end
	end
	-- 遍历并拼接路径检测是否存在，不存在则新建
	for k,v in ipairs(path_tb) do
		if k==1 then
			new_path=v
		else
			new_path=new_path.."/"..v
		end
		lfs.mkdir(new_path)
	end
end
function os.rmdir(path)
    print("os.rmdir:", path)
    --if os.exists(path) then
		local function _rmdir(path)
			--[[
			local iter, dir_obj = lfs.dir(path)
            while true do
                local dir = iter(dir_obj)
                if dir == nil then break end
                if dir ~= "." and dir ~= ".." then
                    local curDir = path..dir
                    local mode = lfs.attributes(curDir, "mode") 
                    if mode == "directory" then
                        _rmdir(curDir.."/")
					elseif mode == "file" then
						print('Remove file:'..curDir)
                        os.remove(curDir)
                    end
                end
			end
			--]]
			for entry in lfs.dir(path) do  
				if entry ~= '.' and entry ~= '..' then  
					local _path = path .. '/' .. entry  
					local attr = lfs.attributes(_path)  
					if attr.mode ~= 'directory' then  
						print('Remove file:'.._path)
                        os.remove(_path)
					else
						_rmdir(_path.."/")
					end  
				end  
			end
			print('Remove path:'..path)
            local succ, des = os.remove(path)
            if des then print(des) end
            return succ
        end
        _rmdir(path)
    --end
    return true
end

function decodeURI(s)
    s = string.gsub(s, '%%(%x%x)', function(h) return string.char(tonumber(h, 16)) end)
    return s
end

function encodeURI(s)
    s = string.gsub(s, "([^%w%.%- ])", function(c) return string.format("%%%02X", string.byte(c)) end)
    return string.gsub(s, " ", "+")
end
function serialize(obj)
    local lua = ""
    local t = type(obj)
    if t == "number" then
        lua = lua .. obj
    elseif t == "boolean" then
        lua = lua .. tostring(obj)
    elseif t == "string" then
        lua = lua .. string.format("%q", obj)
    elseif t == "table" then
        lua = lua .. "{\n"
    for k, v in pairs(obj) do
        lua = lua .. "[" .. serialize(k) .. "]=" .. serialize(v) .. ",\n"
    end
    local metatable = getmetatable(obj)
        if metatable ~= nil and type(metatable.__index) == "table" then
        for k, v in pairs(metatable.__index) do
            lua = lua .. "[" .. serialize(k) .. "]=" .. serialize(v) .. ",\n"
        end
    end
        lua = lua .. "}"
    elseif t == "nil" then
        return nil
    else
        error("can not serialize a " .. t .. " type.")
    end
    return lua
end
function deserialize(lua)
    local t = type(lua)
    if t == "nil" or lua == "" then
        return nil
    elseif t == "number" or t == "string" or t == "boolean" then
        lua = tostring(lua)
    else
        error("can not unserialize a " .. t .. " type.")
    end
    lua = "return " .. lua
    local func = load(lua)
    if func == nil then
        return nil
    end
    return func()
end
function LoadConfig()
	if configuration_file_path==nil then
		configuration_file_path ='B:/config/'..product_key..'.config'
	end
	local str=ReadFile(configuration_file_path)
	if str~=nil then
		print('Load config: '..str)
		local config=deserialize(str)
		if config~=nil then
			configuration=config
		end
	end
end
function SaveConfig()
	local str=serialize(configuration)
	--print('Save config: '..str)
	WriteFile(configuration_file_path, str)
end

--界面耦合
function ShowDialog(title, content, fn)
	local dialog_screen=GetScreenID('Dialog')
	if page_visitor[#page_visitor]~=dialog_screen then
		TLog('Show Dialog: '..title)
		set_text(dialog_screen,2,title)
		set_text(dialog_screen,3,content)
		dialog_deal_function=fn
		change_screen(dialog_screen)
	else
		print('Dialog is opened')
	end
end

function CloseDialog(screen)
	local screen_id=nil
	if screen~=nil and GetScreenID(screen)~=nil then
		table.remove(page_visitor, #page_visitor)
		ChangeScreen(screen)
	else
		change_screen(page_visitor[#page_visitor-1])
	end
end

function ShowLoading(modal, fn, timeout)
	TLog('Show Loading...')
	dialog_deal_function=fn
	loadding_is_modal=modal
	ChangeScreen('Loading')
	if timeout==nil then
		timeout=loading_timeout
	end
	SetTimeOut(3, timeout, function()
		CloseLoading()
	end)
end

function CloseLoading()
	TLog('Close Loading...')
	stop_timer(2)
	change_screen(page_visitor[#page_visitor-1])
end

function ShowLock()
	local lock_screen=GetScreenID('Lock')
	if page_visitor[#page_visitor]~=lock_screen then
		--TLog('Lock screen '..page_visitor[#page_visitor])
		lock_state=1
		ChangeScreen('Lock')
		SendFunctionValue('Lock',1)
	end
end

function CloseLock()
	local lock_screen=GetScreenID('Lock')
	if page_visitor[#page_visitor]==lock_screen then
		TLog('Unlock screen return '..page_visitor[#page_visitor-1])
		lock_state=0
		change_screen(page_visitor[#page_visitor-1])
		SendFunctionValue('Lock',0)
	end
end
--format: "2018-06-01 12:25:15"
function SyncServerTime()
	local sync_time_api='http://api.53iq.com/1/component/current/time'
	HttpGet(11, sync_time_api, function(json_data)
		SLog('Sycn server time...')
		if json_data~=nil and json_data['data']~=nil then
			local server_datetime=json_data['data']['datetime']
			local server_gmt=json_data['data']['timezone']
			SetDateTime(server_datetime)
		end
		GetApiToken()
		StartGetApiToken()
	end)
end
function SetDateTime(datetime)
	TLog('Server DateTime: '..datetime)
	year,month,day,hour,minute,second=string.match(datetime,"^%s*(%d+)[/-](%d+)[/-](%d+)%s+(%d+):(%d+):(%d+)")
	set_date_time(year,month,day,hour,minute,second)
end
function FormatTime(time, format)
	local hour=math.floor(time/3600)
	local minute=math.floor((time-hour*3600)/60)
	local second=math.floor(time-hour*3600-minute*60)
	if format==nil then
		format='%hh:%mm:%ss'
	end
	format=string.gsub( format,'%%h',hour )
	format=string.gsub( format,'%%m',minute )
	format=string.gsub( format,'%%s',second )
	return format
end
function FormatTimeAuto(time)
	if time>3600 then
		return FormatTime(time, '%hh:%mm')
	elseif time>60 then
		return FormatTime(time, '%mm:%ss')
	else
		return FormatTime(time, '%ss')
	end
end
function FormatTemperatureAuto(temp)
	return temp..'°C'
end
--固件升级，ota指定是否自动远程升级
function CheckOTA(api)
	local ota_api = 'http://ota.53iq.com/static/mcu/file/hoode050.txt'
	if api~=nil then
		ota_api=api
	end
	HttpGet(10, ota_api, function(json_data)
		SLog('Check ota...')
		if json_data~=nil then
			print(cjson.encode(json_data))
			configuration['ota_version_code']=math.floor(json_data['versionCode'])
			SaveConfig()
			if api==nil then
				if configuration['ota_version_code']>version_code then
					TLog('version is '..configuration['ota_version_code']..', start upgrade: '..json_data['url'])
					ShowDialog(Lang('Upgrade'),
						string.format(Lang('UpgradeTip'),json_data['versionName']),function() 
							StartUpgrade(json_data['url'])
							--CloseDialog()
							ChangeScreen('Setting')
							set_visiable(GetScreenID('Setting'),94,1)
						end)
				elseif page_visitor[#page_visitor]==GetScreenID('Setting') then
					ShowDialog(Lang('Upgrade'),Lang('LatestVersionTip'))
				end
			else
				StartUpgrade(json_data['url'])
			end
		end
	end)
	upgrade_state=0
end
--界面耦合：事件处理
function StartUpgrade(url)
	if url==nil then
		url='ftp://192.168.191.1/OTA/DCIOT.PKG'
	end
	print('upgrade: '..url)
	start_upgrade(url)
	upgrade_state=1
	set_visiable(GetScreenID('Setting'),94,1)
end

local auchCRCHi = { 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,
		0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1,
		0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
		0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
		0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
		0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1,
		0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
		0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1,
		0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40,
		0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1,
		0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
		0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
		0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
		0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1,
		0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
		0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
		0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40,
		0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
		0x80, 0x41, 0x00, 0xC1, 0x81, 0x40 }
local auchCRCLo = { 0x00, 0xC0, 0xC1, 0x01, 0xC3, 0x03, 0x02, 0xC2, 0xC6, 0x06, 0x07, 0xC7,
		0x05, 0xC5, 0xC4, 0x04, 0xCC, 0x0C, 0x0D, 0xCD, 0x0F, 0xCF, 0xCE, 0x0E, 0x0A, 0xCA,
		0xCB, 0x0B, 0xC9, 0x09, 0x08, 0xC8, 0xD8, 0x18, 0x19, 0xD9, 0x1B, 0xDB, 0xDA, 0x1A,
		0x1E, 0xDE, 0xDF, 0x1F, 0xDD, 0x1D, 0x1C, 0xDC, 0x14, 0xD4, 0xD5, 0x15, 0xD7, 0x17,
		0x16, 0xD6, 0xD2, 0x12, 0x13, 0xD3, 0x11, 0xD1, 0xD0, 0x10, 0xF0, 0x30, 0x31, 0xF1,
		0x33, 0xF3, 0xF2, 0x32, 0x36, 0xF6, 0xF7, 0x37, 0xF5, 0x35, 0x34, 0xF4, 0x3C, 0xFC,
		0xFD, 0x3D, 0xFF, 0x3F, 0x3E, 0xFE, 0xFA, 0x3A, 0x3B, 0xFB, 0x39, 0xF9, 0xF8, 0x38,
		0x28, 0xE8, 0xE9, 0x29, 0xEB, 0x2B, 0x2A, 0xEA, 0xEE, 0x2E, 0x2F, 0xEF, 0x2D, 0xED,
		0xEC, 0x2C, 0xE4, 0x24, 0x25, 0xE5, 0x27, 0xE7, 0xE6, 0x26, 0x22, 0xE2, 0xE3, 0x23,
		0xE1, 0x21, 0x20, 0xE0, 0xA0, 0x60, 0x61, 0xA1, 0x63, 0xA3, 0xA2, 0x62, 0x66, 0xA6,
		0xA7, 0x67, 0xA5, 0x65, 0x64, 0xA4, 0x6C, 0xAC, 0xAD, 0x6D, 0xAF, 0x6F, 0x6E, 0xAE,
		0xAA, 0x6A, 0x6B, 0xAB, 0x69, 0xA9, 0xA8, 0x68, 0x78, 0xB8, 0xB9, 0x79, 0xBB, 0x7B,
		0x7A, 0xBA, 0xBE, 0x7E, 0x7F, 0xBF, 0x7D, 0xBD, 0xBC, 0x7C, 0xB4, 0x74, 0x75, 0xB5,
		0x77, 0xB7, 0xB6, 0x76, 0x72, 0xB2, 0xB3, 0x73, 0xB1, 0x71, 0x70, 0xB0, 0x50, 0x90,
		0x91, 0x51, 0x93, 0x53, 0x52, 0x92, 0x96, 0x56, 0x57, 0x97, 0x55, 0x95, 0x94, 0x54,
		0x9C, 0x5C, 0x5D, 0x9D, 0x5F, 0x9F, 0x9E, 0x5E, 0x5A, 0x9A, 0x9B, 0x5B, 0x99, 0x59,
		0x58, 0x98, 0x88, 0x48, 0x49, 0x89, 0x4B, 0x8B, 0x8A, 0x4A, 0x4E, 0x8E, 0x8F, 0x4F,
		0x8D, 0x4D, 0x4C, 0x8C, 0x44, 0x84, 0x85, 0x45, 0x87, 0x47, 0x46, 0x86, 0x82, 0x42,
		0x43, 0x83, 0x41, 0x81, 0x80, 0x40 }

function CRC16(data, start, len)
	if start==nil then
		start=1
	end
	if len==nil then
		len=#data-start+1
	end
	local uchCRCHi = 0xFF
	local uchCRCLo = 0xFF
	local uIndex
	for i = start, len do
		uIndex = uchCRCHi ~ data[i]
		uIndex = uIndex+1
		uchCRCHi = (uchCRCLo ~ auchCRCHi[uIndex])
		uchCRCLo = auchCRCLo[uIndex]
	end
	value = uchCRCHi << 8 | uchCRCLo
	return value
end

function CheckSum(packet, start, ending)
	local tmpsum=0
	if ending > #packet then
		ending = #packet
	end
	for i=start,ending do
		tmpsum=tmpsum+tonumber(packet[i])
	end
	tmpsum=tmpsum&0xff
	return tmpsum
end
function CheckSumAll(packet)
	local tmpsum=0
	for k, v in pairs(packet) do
		tmpsum=tmpsum+tonumber(v)
	end
	tmpsum=tmpsum&0xff
	return tmpsum
end

--界面耦合
function scan_ap_fill_list()
	--math.randomseed(os.time())
	--ap_cnt=math.random(1,20) 
	local ap_cnt = scan_ap() --扫描可用热点
	local wifi_screen=GetScreenID('WiFi')
	local ssid_page_count=2
	local ssid_page_num=10
	local ssid_page_index=0
	local ssid_screen=0
	local ssid_index_fixed=0
	for i=1,20 do
		local page_index=math.ceil(i/ssid_page_num)
		if ssid_page_index~=page_index then
			ssid_screen=GetScreenID('SSID'..page_index)
			ssid_index_fixed=(page_index-1)*ssid_page_num
		end
		ssid_page_index=page_index
		if i<=ap_cnt then
			ssid='ssid'..i
			security=math.random(1,6)
			quality=math.random(1,88)
			ssid,security,quality = get_ap_info(i-1)
			TLog('ssid:'..ssid..' sec:'..security..' qua:'..quality)
			quality=math.floor(quality/20)
			if quality>5 then
				quality=5
			end
			set_text(ssid_screen,i+60-ssid_index_fixed,ssid)
			set_value(ssid_screen,i+100-ssid_index_fixed,security)
			set_value(ssid_screen,i+110-ssid_index_fixed,quality)
		else
			set_text(ssid_screen,i+60-ssid_index_fixed,'')
			set_value(ssid_screen,i+100-ssid_index_fixed,0)
			set_value(ssid_screen,i+110-ssid_index_fixed,0)
		end
	end
	set_visiable(wifi_screen, 56, 0)
end

function StartTimer(id, timeout, count, onComplete)
	stop_timer(id)
	BindEvent("on_timer", onComplete, id)
	start_timer(id, timeout, 0, count)
end
function SetInterval(id, timeout, onComplete)
	StartTimer(id, timeout, 0, onComplete)
end
function SetTimeOut(id, timeout, onComplete)
	StartTimer(id, timeout, 1, onComplete)
end
function HttpGet(id, url, onComplete)
	BindEvent("on_http_response", onComplete, id)
	http_request(id, url, 0)
end
function HttpGetJson(id, url, onComplete)

end
function HttpPost(id, url, content, data, onComplete)
	BindEvent("on_http_response", onComplete, id)
	http_request(id, url, 1, content, data)
end
function HttpDownload(id, url, path, onComplete)
	BindEvent("on_http_download", onComplete, id)
	http_download(id, url, path)
end

--界面耦合
function WLog(text, screen, control)
	if text~=nil then
		if configuration['ui_log_enable']==1 then
			local text_length_limit=200
			if type(text)=='string' and #text>text_length_limit then
				text=string.sub(text, 1, text_length_limit)
			end
			set_text(screen, control, text)
		end
		print(text)
	end
end
function TLog(text)
	WLog(text, page_visitor[#page_visitor], 999)
end
function SLog(text)
	WLog(text, page_visitor[#page_visitor], 1000)
end
--界面耦合
--获取mac地址
function GetWiFiMac()
	SetInterval(1, 1000, function()
		if mac_string == nil or mac_string == '' then
			mac_string = get_wifi_mac()
			TLog('Mac Address: '..mac_string)
			if mac_string ~= nil and mac_string ~= ''
				and mac_string~="000000000000" then
				mac_packet = StringToBytes(mac_string)
				product_key_packet = StringToBytes(product_key)
				TLog(BytesToHexString(mac_packet))
				local qr_screen=GetScreenID('Qrcode')
				set_text(qr_screen,2,'https://oven.53iq.com/api/user/bind/device?device_id='..mac_string)
				set_text(qr_screen,3,mac_string)
			end
		else
			stop_timer(1)
		end
	end)
end
--开启自动休眠机制
function EnablePowerManage()
	if configuration['power_manage_enable']==1 then
		SetTimeOut(0, configuration['auto_sleep_delay'], function()
			SendFunctionValue('Power',0)
			if configuration['low_power']==1 then
				sleepmode(1)
			else
				set_backlight(0)
			end
		end)
		--SLog('Power manage enabled')
	end
end
--关闭自动休眠机制
function DisablePowerManage()
	stop_timer(0)
	--SLog('Power manage disabled')
end
function ScanAP()
	TLog('AP will scan after 100 ms')
	SetTimeOut(2, 100, function()
		scan_ap_fill_list()
	end)
end
function Lang(name, lang)
	if lang==nil then
		lang=configuration['language']
	end
	local language=languages[lang]
	return language[name]
end
--界面耦合
function on_init()
	print('System init')
	--cjson = require "cjson"
	--require "lfs"
	LoadConfig()
	SLog('System Language: '..configuration['language'])
	if configuration['language']~=nil then
		set_value(GetScreenID('Setting'),122,configuration['language'])
		set_language(configuration['language'])
	end
	TLog('system started: '..get_date_time())
	set_backlight(configuration['backlight'])
	uart_set_timeout(50, 2) 

	GetWiFiMac()
	RegisterServer()
	EnablePowerManage()
	SendFunctionValue("Power",1)
	--[[
	local model_pages={GetScreenID('Child1'),GetScreenID('Child2')}
	for k,v in pairs(model_pages) do
		TLog('model page '..v)
		for i=1,6 do
			local model=GetModel(page_models[v][i])
			set_text(v, i+10, model.temperature..'°C\r\n'..model.time..'m')
		end
	end
	--]]
	SetInterval(10, 1000, function()
		--SendDeviceState()
	end)
	if configuration["FirstVisit"]==nil then
		configuration["FirstVisit"]=false
		ChangeScreen('ProductCenter')
	end
	set_text(GetScreenID('Main'),2,'欢迎使用')
	set_text_roll(GetScreenID('Main'),2,50)
end

function on_timer(timer)
	local timer_complete=GetEvent("on_timer", timer)
	if timer_complete~=nil then
		timer_complete()
	end
end
--界面耦合
function on_systick()
	local net_connect = get_network_state()
	if net_connect~=net_connect_status then
		print('WiFi connect state: '..net_connect)
	end

	SetNetStateView(net_connect)

	if net_connect>0 then
		if net_connect_status==0 then
			if configuration['sync_server_time']==1 then
				SyncServerTime()
				CheckOTA()
			end
		end
		local wificonfig_screen=GetScreenID('WiFiConfig')
		if page_visitor[#page_visitor]==wificonfig_screen and get_text(wificonfig_screen,11)~='' then
			ChangeScreen('WiFi')
		end

		if net_connect==5 then
			server_connect_status=2
		end
	else
		server_connect_status=0
	end
	net_connect_status=net_connect

	if upgrade_state ~= 0 then
		upgrade_state,process = get_upgrade_state() --获取更新状态与进度
		local setting_screen=GetScreenID('Setting')
		set_value(setting_screen,94,process)
		set_value(setting_screen,95,upgrade_state)  --升级状态提示
		if upgrade_state==4 and configuration['ui_log_enable']==1 then	--本地升级失败则继续走网络升级
			CheckOTA()
		end
		if selected_product>0 then
			set_value(GetScreenID('ProductCenter'),101,process)
		end
	end
	
	local main_screen=GetScreenID('Main')
	local child_screen=GetScreenID('Child1')
	set_value(main_screen, 52, get_value(main_screen, 51)-child_screen)
end

function on_wakeup()
	TLog('WakeUp')
	set_backlight(configuration['backlight'])
	SendFunctionValue('Power',1)
	EnablePowerManage()
end

function RegisterServer()
	set_network_service_cfg(1, 1, configuration['server_port'], configuration['server_address'])
	server_connect_status=1
	TLog('Register Server:'..configuration['server_address']..':'..configuration['server_port'])
end
function GetApiToken()
	if api_token==nil then
		TLog('Start get api token')
		local token_api='http://api.53iq.com/1/token?appid=53cj4yM60moHcPdHSy&secret=f3IgWCcEam9ip2G38PU0i5k4RvhYKrCW&grant_type=client_credential'
		HttpGet(100,token_api,function(json_data)
			if json_data~=nil and json_data['data']~=nil then
				api_token=json_data['data']['access_token']
			end
			TLog('Get Token: '..api_token)
		end)
	end
end
function StartGetApiToken()
	SetInterval(4, 60000, function()
		GetApiToken()
	end)
end
function SetNetStateView(state)
	if state==nil then
		state=net_connect_status
	end
	local setting_screen=GetScreenID('Setting')
	local wifi_screen=GetScreenID('WiFi')
	set_value(setting_screen,53,state)
	set_value(wifi_screen,53,state)
	if state>0 then
		wifimode,secumode,ssid,password = get_wifi_cfg()
		dhcp,ipaddr = get_network_cfg()
		set_text(wifi_screen,54,ssid)
		set_text(wifi_screen,55,ipaddr)
		set_text(setting_screen,54,ssid)
		set_text(setting_screen,55,ipaddr)
		set_value(page_visitor[#page_visitor],26,1)
		--set_enable(page_visitor[#page_visitor],10,1)
		if state~=net_connect_status then
			print('WiFi connected: '..ssid..', ip: '..ipaddr)
		end
	else
		set_text(wifi_screen,54,'')
		set_text(wifi_screen,55,'')
		set_text(setting_screen,54,'')
		set_text(setting_screen,55,'')
		set_value(page_visitor[#page_visitor],26,0)
		--set_enable(page_visitor[#page_visitor],10,0)
		if state~=net_connect_status then
			print('WiFi disconnected!')
		end
	end
end

--界面耦合
function on_control_notify(screen,control,value)
	OperateFunctionValues(screen,control,value)	--设备功能操作，自动关联配置控件
	local screen_name,screen_title=GetScreenName(screen)
	--eval, screen_name..'PageProcess('..control..','..value..')'
	----[[
	if control==10 then	--智能帮助
		if net_connect_status>0 then
			local status_string
			for k,v in ipairs(device_function) do
				if v.value~=nil then
					if status_string==nil then
						status_string='{"'..v.name..'":"'..v.value..'"'
					else
						status_string=status_string..', "'..v.name..'":"'..v.value..'"'
					end
				end
			end
			status_string=status_string.."}"
			local help_url= "http://oven.53iq.com/api/device/helper"
			--[[
			help_url=help_url.."?device_id="..mac_string
			help_url=help_url.."&device_type="..device_type
			help_url=help_url.."&device_key="..product_key
			help_url=help_url.."&page="..screen_name
			help_url=help_url.."&mode="..selected_model
			status_string=GetFunctionValue("State")
			help_url=help_url.."&status="..status_string
			HttpGet(1, help_url, function(json_data)
				if json_data~=nil then
					local resp_code=json_data["code"]
					local resp_result="帮助信息已发送至智能厨房App"
					if resp_code~=0 then
						resp_result="请先扫描屏幕左上角二维码，下载智能厨房App，绑定设备"
					end
					TLog('help response code:'..resp_code)
				end
			end)
			SLog('Get Help: '..help_url)
			help_url= "http://oven.53iq.com/api/device/helper"
			--]]
			local help_data='{'
			help_data=help_data..'"device_id":"'..mac_string..'"'
			help_data=help_data..',"device_type":"'..device_type..'"'
			help_data=help_data..',"device_key":"'..product_key..'"'
			help_data=help_data..',"page":"'..screen_name..'"'
			help_data=help_data..',"status":'..status_string
			help_data=help_data..'}'
			SLog('Post Help: '..help_data)
			HttpPost(1, help_url,'application/json', help_data, function(json_data)
				if json_data~=nil then
					local resp_code=json_data["code"]
					local resp_result=Lang("MessageSendSuccessTip")
					if resp_code==3007 then
						resp_result=Lang("NeedBindDeviceTip") 
					elseif resp_code~=0 then
						resp_result=Lang("MessageSendFailTip").."："..json_data["msg"]..'('..resp_code..')'
					end
					--TLog('help response code:'..resp_code)
					set_text(GetScreenID('Dialog'),3,resp_result)
				end
			end)
			local help_title=screen_title..' '
			if selected_model>=0 then
				help_title=help_title..GetModel(selected_model).name
			end
			help_title=help_title..'\r\n'..Lang('MessageSendingTip')
			ShowDialog(Lang('SmartHelp'),help_title)
		else
			ShowDialog(Lang('SmartHelp'),Lang('NeedConnectWiFi'),function()
				ChangeScreen('WiFi')
			end)
		end
	elseif control==4 and control_id_rule>=4 then
		if value==1 then
			if #page_visitor>1 then
				change_screen(page_visitor[#page_visitor-1])
			end
		end
	elseif control>30 and control<100 and control_id_rule>=99 then
		if value>0 then
			local control_action=control%10
			local control_target_level=math.floor(control/10)*10
			local control_target=control_target_level+5
			local control_target_value=math.round(get_value(screen,control_target))	--四舍五入
			if control_action==9 then
				control_target=control_target_level+10
			end
			
			if control_action==1 then	--上一个
				if control_target_value<=0 then
					control_target_value=0
				else
					control_target_value=control_target_value-1
				end
			elseif control_action==2 then	--下一个
				control_target_value=control_target_value+1
			elseif control_action==3 then	--第一个
				control_target_value=0
			elseif control_action==4 then	--最后一个
				control_target_value=255
			elseif control_action==9 then
				control_target_value=value
			end
			set_value(screen,control_target,control_target_value)
		end
	elseif control==23 then
		TLog('Lock Screen')
		--ShowLock(screen)
	end
	if screen_name=='Main' then	--主页面控件事件处理
		if control==21 then
			SLog('power_manage_enable'..configuration['power_manage_enable'])
			if configuration['power_manage_enable']==1 then
				if configuration['low_power']==0 then
					local state=ChangeFunctionSwitch("Power")
					if state==0 then
						need_sleep=1
					end
				else
					--SendFunctionValue('Power',0)
					sleepmode(1)
				end
			else
				TLog('Lock Screen')
				ShowLock()
			end
		end
	elseif screen_name=='ProductCenter' then
		local ota_info={
			'http://ota.53iq.com/static/mcu/file/embedsteamer.txt',
			'http://ota.53iq.com/static/mcu/file/washe043.txt',
			'http://ota.53iq.com/static/mcu/file/hoode050.txt'
		}
		if control==100 then
			if selected_product>0 then
				CheckOTA(ota_info[selected_product])
				set_visiable(screen,101,1)
			end
		elseif math.floor(control/10)==11 then
			selected_product=control%10
			for i=1,3 do
				if i~=selected_product then
					set_value(screen,110+i,0)
				end
			end
		end
	elseif screen_name=='SSID1' or screen_name=='SSID2' then	--热点选择页面
		if control>=71 and control<=80 then
			ssid = get_text(screen,control-10) --文本控件从1~10
			SLog('Selected SSID is '..ssid)
			if ssid~='' then
				local wificonfig_screen=GetScreenID('WiFiConfig')
				set_text(wificonfig_screen,2,ssid)
				set_value(wificonfig_screen,12,get_value(screen,control+30))
				wifimode,secumode,last_ssid,password = get_wifi_cfg()
				if ssid~=last_ssid then
					set_text(wificonfig_screen,3,'')
					set_text(wificonfig_screen,4,'')
				end
				ChangeScreen('WiFiConfig')
			end
		end
	elseif screen_name=='Setting' then	--设置页面
		if control==63 then	--背光亮度设置
			set_value(screen,62, value)
			set_backlight(value)
			configuration['backlight']=value
		elseif control==77 then --同步时间
			configuration['sync_server_time']=value
			if value==1 then
				SyncServerTime()
			end
		elseif control==82 then	--屏幕保护设置（自动休眠）
			configuration['power_manage_enable']=value
			if value==0 then
				DisablePowerManage()
				set_visiable(screen,83,0)
				set_visiable(screen,84,0)
				set_visiable(screen,85,0)
			else
				TLog('Start auto sleep delay '..configuration['auto_sleep_delay'])
				EnablePowerManage()
				set_visiable(screen,83,1)
				set_visiable(screen,84,1)
				set_visiable(screen,85,1)
			end
		elseif control==84 then
			local current_sleep_time=math.floor(get_value(screen,83))
			current_sleep_time=current_sleep_time+3
			if current_sleep_time>30 then
				if configuration['ui_log_enable']==1 then
					current_sleep_time=0.1
				else
					current_sleep_time=3
				end
			end
			configuration['auto_sleep_delay']=current_sleep_time*60000
			DisablePowerManage()
			EnablePowerManage()
			if current_sleep_time>1 then
				current_sleep_time=math.floor(current_sleep_time)
			end
			set_value(screen,83,current_sleep_time)
		elseif control==102 then	--UI日志开关
			if value==0 then
				TLog('')
				SLog('')
			end
			configuration['ui_log_enable']=value
		elseif control==123 or  control==124 or  control==125 then
			for i=123,125 do
				if i~=control then
					set_value(screen,i,0)
				end
			end
			local language=control-123
			set_language(language)
			configuration['language']=language
			SaveConfig()
		elseif control==93 then
			if value==1 then
				if upgrade_state==0 or upgrade_state==4 then
					if configuration['ui_log_enable']==1 then
						--开启界面调试日志时直接走本地升级
						StartUpgrade()
					else
						CheckOTA()
					end
				end
			end
		elseif control==122 then
			set_language(value)
			configuration['language']=value
			SaveConfig()
		elseif control==12 then	--保持设置
			SaveConfig()
		elseif control==103 or control==104 then
			if net_connect_status>0 then
				local api_url='http://oven.53iq.com/api/device/switch_to'
				local post_data='{'
				post_data=post_data..'"device_id":"'..mac_string..'"'
				post_data=post_data..',"device_type":"'..device_type..'"'
				post_data=post_data..',"device_key":"'..product_key..'"'
				if control==103 then
					post_data=post_data..',"action":"register"'
				else
					post_data=post_data..',"action":"repair"'
				end
				post_data=post_data..'}'
				SLog('Post API: '..post_data)
				HttpPost(1, api_url,'application/json', post_data, function(json_data)
					if json_data~=nil then
						local resp_code=json_data["code"]
						local resp_result=Lang("MessageSendSuccessTip")
						if resp_code==3007 then
							resp_result=Lang("NeedBindDeviceTip")
						elseif resp_code~=0 then
							resp_result=Lang("MessageSendFailTip").." "..json_data["msg"]..'('..resp_code..')'
						end
						set_text(GetScreenID('Dialog'),3,resp_result)
					end
				end)
				if control==103 then
					ShowDialog(Lang("Register"),Lang("MessageSendingTip"))
				else
					ShowDialog(Lang("Repair"),Lang("MessageSendingTip"))
				end
			else
				if control==103 then
					ShowDialog(Lang("Register"),Lang("NeedConnectWiFi"),function()
						ChangeScreen('WiFi')
					end)
				else
					ShowDialog(Lang("Repair"),Lang("NeedConnectWiFi"),function()
						ChangeScreen('WiFi')
					end)
				end
			end
		end
	elseif screen_name=='WiFi' then	--WiFi热点搜索页面
		if control==51 then
			set_visiable(screen, 56, 1)
			--scan_ap_fill_list()
			ScanAP()
		elseif control>=71 and control<=80 then
			ssid = get_text(screen,control-10) --文本控件从1~10
			SLog('Selected SSID is '..ssid)
			local wificonfig_screen=GetScreenID('WiFiConfig')
			set_text(wificonfig_screen,2,ssid)
			wifimode,secumode,last_ssid,password = get_wifi_cfg()
			if ssid~=last_ssid then
				set_text(wificonfig_screen,3,'')
				set_text(wificonfig_screen,4,'')
			end
		end
	elseif screen_name=='WiFiConfig' then
		if control==7 then
			ssid = get_text(screen,2)
			if get_value(screen,5)==1 then
				psw = get_text(screen,4)
			else
				psw = get_text(screen,3)
			end
			security=get_value(screen,12)
			TLog('Connect ssid:'..ssid..' sec:'..security)
			set_text(screen,11,'连接中..')
			set_wifi_cfg(1,security,ssid,psw) --1网卡模式，0自动识别加密
			save_network_cfg();
			set_visiable(screen,9,1)
			configuration['wifi_ssid']=ssid
			configuration['wifi_pwd']=psw
			configuration['wifi_security']=security
			SaveConfig()
		elseif control==5 then
			if value==1 then
				set_text(screen,4,get_text(screen,3))
				set_visiable(screen,4,1)
				set_visiable(screen,3,0)
			else
				set_text(screen,3,get_text(screen,4))
				set_visiable(screen,4,0)
				set_visiable(screen,3,1)
			end
		end
	elseif screen_name=='Qrcode' then	--二维码绑定页面
		if control==112 then
			configuration['remote_control_enable']=value
			SaveConfig()
		end
	elseif screen_name=='Dialog' then	--对话框页面
		if value==1 then
			if control==7 and dialog_deal_function~=nil then
				dialog_deal_function()
			else
				CloseDialog()
			end
		end
	elseif screen_name=='Loading' then	--对话框页面
		if loadding_is_modal==false then
			CloseLoading()
		end
	elseif screen_name=='Lock' then
		if control==1 then
			if value==1 then
				unlock_time=0
			elseif value==2 and lock_state==1 then
				unlock_time=unlock_time+360/(unlock_timeout/1000/0.1)
				if unlock_time>=360 then
					CloseLock()
					lock_state=0
					unlock_time=0
				end
			elseif value==0 then
				unlock_time=0
			end
			set_value(screen,2,360-unlock_time)
		end
	end
	RaiseEvent("on_control_notify")
	--]]
end
--界面耦合
function on_screen_change(screen)
	last_screen=page_visitor[#page_visitor]
	local page_cookies=''
	for k,v in pairs(page_visitor) do
		if v==screen then
			local visitor_len=#page_visitor
			for i=k,#page_visitor do
				table.remove(page_visitor, visitor_len+k-i)
			end
			break
		end
		page_cookies=page_cookies..v..' > '
	end
	page_visitor[#page_visitor+1]=screen
	page_cookies=page_cookies..screen
	print(page_cookies)

	if configuration['ui_log_enable']==0 then
		set_text(screen,99,'')
		set_text(screen,100,'')
	end
	--禁用状态栏按键的点击
	for i=26,26 do
		set_enable(screen,i,0)
	end
	SetNetStateView()

	local screen_name=GetScreenName(screen)
	if pcall(eval, screen_name..'PageOpen('..screen..')') then
		print(screen_name..' Page Opened')
	else

	end
end

function on_press(stat, x, y)
	if stat==0 then
		if configuration['power_manage_enable']==1 then
			if need_sleep==1 then
				need_sleep=0
				if configuration['low_power']==1 then
					sleepmode(1)
				else
					set_backlight(0)
				end
			else
				if get_backlight()==0 then
					set_backlight(configuration['backlight'])
					SendFunctionValue('Power',1)
				end
			end
		end
	elseif stat==1 then
		local auto_sleep_time=get_timer_value(0)
		--TLog('Auto sleep time:'..auto_sleep_time..'/'..configuration['auto_sleep_delay'])
		if auto_sleep_time>0 then
			DisablePowerManage()
			EnablePowerManage()
		end
	end
end

function SettingPageOpen(screen)
	if upgrade_state~=0 then
		set_visiable(screen,94,1)
	else
		set_visiable(screen,94,0)
	end
	set_value(screen,62,configuration['backlight'])
	set_value(screen,63,configuration['backlight'])
	set_value(screen,77,configuration['sync_server_time'])
	set_value(screen,82, configuration['power_manage_enable'])
	set_value(screen,83,math.floor(configuration['auto_sleep_delay']/60000))
	set_text(screen,92,version_name)
	set_value(screen,102,configuration['ui_log_enable'])
	set_value(screen,112,configuration['remote_control_enable'])
	set_value(screen,122,configuration['language'])
	for i=123,125 do
		if configuration['language']==i-123 then
			set_value(screen,i,1)
		else
			set_value(screen,i,0)
		end
	end
	if configuration['ota_version_code']~=nil 
		and configuration['ota_version_code']>version_code then
		set_value(screen,97,1)
	else
		set_value(screen,97,0)
	end
end
function WiFiPageOpen(screen)
	local wificonfig_screen=GetScreenID('WiFiConfig')
	if last_screen~=wificonfig_screen then
		ScanAP()
	end
end
function WiFiConfigPageOpen(screen)
	set_text(screen,11,'')
	set_visiable(screen,9,0)
	if configuration['wifi_ssid']==get_text(screen,2) then
		set_text(screen,3,configuration['wifi_pwd'])
		set_text(screen,4,configuration['wifi_pwd'])
	end
end

function QrcodePageOpen(screen)
	set_value(screen,112,configuration['remote_control_enable'])
end

function LockPageOpen()
	unlock_time=0
end

function ProductCenterPageOpen(screen)
	if upgrade_state~=0 then
		set_visiable(screen,101,1)
	else
		set_visiable(screen,101,0)
	end
end

function StringToBytes(str)
	local arr = {}
	local index = 0
	while ( index < #str) do
		local num = string.byte(str, index+1)
		arr[index] = num
		index = index + 1
	end
	return arr
end

function BytesToString(arr, split)
	if split==nil then
		split=' '
	end
	local str = ""
	for k, v in ipairs(arr) do
		str = str..string.format("%c", v)..split
	end
	return str
end

function BytesToHexString(arr, split)
	if split==nil then
		split=' '
	end
	local str = ""
	--[[
	for k, v in ipairs(arr) do
		str = str..string.format("%X", v)..split
	end--]]
	for i=0,#arr do
		if arr[i]~=nil then
			str=str..string.format("%X", arr[i])..split
		end
	end
	return str
end
--正整数转bytes，默认大端编码
function IntToBytes(num,endian,len)
	local t={}
	local remainder
	while(num>255) do
		remainder=num%256
		num=math.floor(num/256)
		t[#t+1]=remainder
	end
	t[#t+1]=num
	if len~=nil and len>#t then
		for i=#t+1,len do
			t[i]=0
		end
	end
	if endian==nil or endian>0 then
		table.reverse(t)
	end
	return t
end
function table.getstart(t)
	for i=0,#t do
		if t[i]~=nil then
			return i
		end
	end
	return 1
end
function table.reverse(t)
	local start=table.getstart(t)
	for i=0, math.floor(#t/2-1) do
		local temp=t[#t-i]
		t[#t-i]=t[i+start]
		t[i+start]=temp
	end
end
function table.equals(src, desc, start, finish)
	if start==nil then
		start=table.getstart(desc)
	end
	if finish==nil then
		finish=#desc
		if finish>#src then
			finish=#src
		end
	else
		if finish>#desc or #finish>#src then
			return false
		end
	end
	local _start=table.getstart(src)
	for i=_start, finish do
		if src[i]~=desc[start+i-_start] then
			return false
		end
	end
	return true
end
function math.round(num)
	return math.floor(num+0.5)
end
function BytesToInt(t, start, finish, endian)
	local num=0
	if start==nil then
		start=table.getstart(t)
	end
	if finish==nil then
		finish=#t
	end
	for i=start, finish do
		if endian==nil or endian>0 then
			num=num+t[i]*256^(finish-i)
		else
			num=num+t[i]*256^(i-start)
		end
	end
	return math.floor(num)
end

function on_http_response(sn,resp)
	--SLog('HttpResponse Code:'..sn) 
	if resp~=nil and resp~='' then
		TLog('HttpResponse:'..resp)
	end
	local http_response=GetEvent("on_http_response", sn)
	if http_response~=nil then
		local json_data = cjson.decode(resp)
		if json_data~=nil then
			http_response(json_data)
		else
			http_response(resp)
		end
	end
end

function on_http_download(sn,result)
	SLog(sn..' download completed')
	local http_download=GetEvent("on_http_download", sn)
	if http_download~=nil then
		http_download(result)
	end
end

--系统底层接口方法有效装饰器，由于本地调试跳过系统方法
function LocalDecorator(func)
	local function _dec_in(...)
		if func==nil then
			return
		end
		local input = { ... }
		for key, value in pairs(input) do
			--参数判断
		end
		return func( ... )
	end
	return _dec_in
end

function Test()
	configuration['ui_log_enable']=0
	set_value=LocalDecorator(set_value)
	set_text=LocalDecorator(set_text)
	uart_send_data=LocalDecorator(uart_send_data)
	change_screen=LocalDecorator(change_screen)
	stop_timer=LocalDecorator(stop_timer)

	local bytes=IntToBytes(1095232258269,1)
	local integer=BytesToInt(bytes)
	local bytes=IntToBytes(1095232258269,0)
	local integer=BytesToInt(bytes,1,#bytes,0)
	local equals=table.equals({0xA5, 0X5A}, {[0]=0xA5, 0x5A, 0x01, 0x00, 0x00, 0x00, 0x20})
	
	local crc_data={[0]=0xA5, 0x01, 0x01, 0x00, 0x08, 0x00, 0x01, 0x92, 0x19}
	ProcessUartCommand(crc_data)
	ProcessUartCommand(crc_data)
	GetDeviceCommand()
	on_control_notify(0,114,1)
	on_control_notify(0,115,1)
	on_control_notify(0,102,0)
	on_control_notify(0,102,1)
	on_control_notify(0,111,1)
	on_control_notify(0,102,1)
	on_control_notify(0,101,0)

	BindEvent('my_event', function(id, str) 
		print(id..str) 
	end)
	BindEvent('my_event', function(id, str) 
		print(id..str) 
	end)
	local callback=function(id, str)
		print(id..str)
	end
	BindEvent('my_event', callback)
	BindEvent('my_event', callback)
	RaiseEvent("my_event", 1, 'abc')
	UnbindEvent('my_event', callback)
	RaiseEvent("my_event", 2, 'abc')

	local uri=encodeURI('你我他')
	decodeURI(uri)

	ProcessNetCommand({[0]=0xA5, 0x5A, 0x13, 0x21, 0x05, 0x00, 0x08, 0x00, 0x01, 0x24, 0x65})

	SendFunctionValues({
		Light=1,
		Fan1=1,
		Fan2=0,
		Fan3=0
	})
	AnalyzeCombFunctionData({0xA5, 0x5A, 0x01, 0x21, 0x0C, 0x01, 0x01, 0x03, 0x01, 0x05, 0x01, 0x07, 0x00, 0x01, 0x0C, 0x03, 0x04, 0x95}, 6, 12)

	year,month,day,hour,minute,second=string.match("2018-06/01 12:13:14","^%s*(%d+)[/-](%d+)[/-](%d+)%s+(%d+):(%d+):(%d+)")

	--local jsonTable = iqkit.json2lua('{"code": 0, "data": {"expires_in": 0, "access_token": "YeAppCNWbhUPN6tfGNeOjiNEbpBOZ0tNfwlSnwRrwBOvCEdR3L9nGdS3JdU9y9nJ_70ae2e30737a29db4469252976e64008b5c7963e"}, "msg": "success"}')
	--print(iqkit.table2json(jsonTable))
	--local json=require("json")
	--local jsonTable = luaJson.json2lua('{"code": 0, "data": {"expires_in": 0, "access_token": "YeAppCNWbhUPN6tfGNeOjiNEbpBOZ0tNfwlSnwRrwBOvCEdR3L9nGdS3JdU9y9nJ_70ae2e30737a29db4469252976e64008b5c7963e"}, "msg": "success"}')

	--local sampleJson = [[{"age":"23","testArray":{"array":[8,9,11,14,25]},"Himi":"himigame.com"}]];
	--解析json字符串
	--local json_data = cjson.decode(sampleJson)
	--local json_string= cjson.encode(json_data)

	local link_string=''
	for i=0,59 do
		link_string=link_string..i..';'
	end
	print(link_string)

	local objstr=serialize(configuration)
	local obj=deserialize(objstr)

	local screen_name=GetScreenName(8)
	if pcall(eval, screen_name..'PageOpen()') then
		print(1)
	else
		print(0)
	end
	
	local data=GetFunctionData(1)

	--ProcessUartCommand({[0]=0xA5, 0x15, 0x02, 0x00, 0x1, 0x81, 0x01, 0x01, 0x64, 0x5F})
	--ProcessUartCommand({[0]=0x6E, 0x00, 0x0A, 0x8C, 0x07, 0x08, 0x0E, 0x10, 0x00, 0x00, 0x00, 0x00, 0x8F})

	AnalyzeFunctionData({0xA5, 0x15, 0x00, 0x00, 0x01, 0x85, 0x01, 0x02, 0x64, 0x5F, 0x6E, 0x00, 0x0A, 0x8C, 0x07, 0x08, 0x0E, 0x10, 0x00, 0x00, 0x00, 0x00, 0x92, 0x95}, 6)
	SetFunctionValue("Light", 0)
	local data=GetFunctionData(1)

	configuration['ui_log_enable']=1
end
--pcall(Test())
