--//*******************53iq iqkit*********************//
--2018/06/07    Zhujian
--基于Lua 5.2及以上版本
--53iq封装的用于WiFi嵌入式屏的Lua脚本库
--主要提供Json转换、table序列化、16进制数据处理、校验算法等工具方法
--实现针对53iq厨电开发平台标准协议的对接，包含云端、APP和电控端的通信控制
--封装系统标准子功能模块，包含配置持久化、OTA升级、时间同步、电源管理（休眠唤醒）
--封装53iq平台云菜谱功能
--//*******************************************//
iqkit={}

--//******************eval方法*******************//
--脚本内容字符执行方法，可实现类似反射的效果
--//*******************************************//
function iqkit.eval(equation, variables)
    if(type(equation) == "string") then
        local eval = load("return "..equation);
        if(type(eval) == "function") then
            --setfenv(eval, variables or {});
            return eval();
        end
    end
end
--//******************工具类部分*******************//
--//*******************Json 工具类*********************//
--//实现Json和Lua中的table的互转,这个原理是逐个解析字符串，同样可以解析json、xml
--//Json字符串转table: iqkit.json2lua(str)
--//table转Json字符串：iqkit.table2json(tab)
--//*******************************************//
local function json2true(str, from, to)
    return true, from + 3
end
local function json2false(str, from, to)
    return false, from + 4
end
local function json2null(str, from, to)
    return nil, from + 3
end
local function json2nan(str, from, to)
    return nul, from + 2
end
local numberchars = {
    ['-'] = true,
    ['+'] = true,
    ['.'] = true,
    ['0'] = true,
    ['1'] = true,
    ['2'] = true,
    ['3'] = true,
    ['4'] = true,
    ['5'] = true,
    ['6'] = true,
    ['7'] = true,
    ['8'] = true,
    ['9'] = true,
}
local function json2number(str, from, to)
    local i = from + 1
    while (i <= to) do
        local char = string.sub(str, i, i)
        if not numberchars[char] then
            break
        end
        i = i + 1
    end
    local num = tonumber(string.sub(str, from, i - 1))
    if not num then
        Log("red", 'json格式错误，不正确的数字, 错误位置:', from)
    end
    return num, i - 1
end
local function json2string(str, from, to)
    local ignor = false
    for i = from + 1, to do
        local char = string.sub(str, i, i)
        if not ignor then
            if char == '\"' then
                return string.sub(str, from + 1, i - 1), i
            elseif char == '\\' then
                ignor = true
            end
        else
            ignor = false
        end
    end
    Log("red", 'json格式错误，字符串没有找到结尾, 错误位置:{from}', from)
end
local function json2array(str, from, to)
    local result = {}
    from = from or 1
    local pos = from + 1
    local to = to or string.len(str)
    while (pos <= to) do
        local char = string.sub(str, pos, pos)
        if char == '\"' then
            result[#result + 1], pos = json2string(str, pos, to)
        --[[    elseif char == ' ' then
        
        elseif char == ':' then
        
        elseif char == ',' then]]
        elseif char == '[' then
            result[#result + 1], pos = json2array(str, pos, to)
        elseif char == '{' then
            result[#result + 1], pos = iqkit.json2table(str, pos, to)
        elseif char == ']' then
            return result, pos
        elseif (char == 'f' or char == 'F') then
            result[#result + 1], pos = json2false(str, pos, to)
        elseif (char == 't' or char == 'T') then
            result[#result + 1], pos = json2true(str, pos, to)
        elseif (char == 'n') then
            result[#result + 1], pos = json2null(str, pos, to)
        elseif (char == 'N') then
            result[#result + 1], pos = json2nan(str, pos, to)
        elseif numberchars[char] then
            result[#result + 1], pos = json2number(str, pos, to)
        end
        pos = pos + 1
    end
    Log("red", 'json格式错误，表没有找到结尾, 错误位置:{from}', from)
end
local function string2json(key, value)
    return string.format("\"%s\":\"%s\",", key, value)
end
local function number2json(key, value)
    return string.format("\"%s\":%s,", key, value)
end
local function boolean2json(key, value)
    value = value == nil and false or value
    return string.format("\"%s\":%s,", key, tostring(value))
end
local function array2json(key, value)
    local str = "["
    for k, v in pairs(value) do
        str = str .. iqkit.table2json(v) .. ","
    end
    str = string.sub(str, 1, string.len(str) - 1) .. "]"
    return string.format("\"%s\":%s,", key, str)
end
local function isArrayTable(t)
    
    if type(t) ~= "table" then
        return false
    end
    
    local n = #t
    for i, v in pairs(t) do
        if type(i) ~= "number" then
            return false
        end
        
        if i > n then
            return false
        end
    end
    
    return true
end
local function table2json(key, value)
    if isArrayTable(value) then
        return array2json(key, value)
    end
    local tableStr = iqkit.table2json(value)
    return string.format("\"%s\":%s,", key, tableStr)
end
function iqkit.json2table(str, from, to)
    local result = {}
    from = from or 1
    local pos = from + 1
    local to = to or string.len(str)
    local key
    while (pos <= to) do
        local char = string.sub(str, pos, pos)
        --Log("yellow", pos, "-->", char)
        if char == '\"' then
            if not key then
                key, pos = json2string(str, pos, to)
            else
                result[key], pos = json2string(str, pos, to)
                key = nil
            end
        --[[    elseif char == ' ' then
        
        elseif char == ':' then
        
        elseif char == ',' then]]
        elseif char == '[' then
            if not key then
                key, pos = json2array(str, pos, to)
            else
                result[key], pos = json2array(str, pos, to)
                key = nil
            end
        elseif char == '{' then
            if not key then
                key, pos = iqkit.json2table(str, pos, to)
            else
                result[key], pos = iqkit.json2table(str, pos, to)
                key = nil
            end
        elseif char == '}' then
            return result, pos
        elseif (char == 'f' or char == 'F') then
            result[key], pos = json2false(str, pos, to)
            key = nil
        elseif (char == 't' or char == 'T') then
            result[key], pos = json2true(str, pos, to)
            key = nil
        elseif (char == 'n') then
            result[key], pos = json2null(str, pos, to)
            key = nil
        elseif (char == 'N') then
            result[key], pos = json2nan(str, pos, to)
            key = nil
        elseif numberchars[char] then
            if not key then
                key, pos = json2number(str, pos, to)
            else
                result[key], pos = json2number(str, pos, to)
                key = nil
            end
        end
        pos = pos + 1
    end
    Log("red", 'json格式错误，表没有找到结尾, 错误位置:{from}', from)
end
--json格式中表示字符串不能使用单引号
local jsonfuncs = {
    ['\"'] = json2string,
    ['['] = json2array,
    ['{'] = iqkit.json2table,
    ['f'] = json2false,
    ['F'] = json2false,
    ['t'] = json2true,
    ['T'] = json2true,
}
function iqkit.json2lua(str)
    local char = string.sub(str, 1, 1)
    local func = jsonfuncs[char]
    if func then
        return func(str, 1, string.len(str))
    end
    if numberchars[char] then
        return json2number(str, 1, string.len(str))
    end
end
function iqkit.table2json(tab)
    local str = "{"
    for k, v in pairs(tab) do
        if type(v) == "string" then
            str = str .. string2json(k, v)
        elseif type(v) == "number" then
            str = str .. number2json(k, v)
        elseif type(v) == "boolean" then
            str = str .. boolean2json(k, v)
        elseif type(v) == "table" then
            str = str .. table2json(k, v)
        end
    end
    str = string.sub(str, 1, string.len(str) - 1)
    return str .. "}"
end
--//*********************Json工具类结束*************************//

--//*******************序列化工具类*********************//
--//实现对象序列化和反序列化，可用于简单信息的持久化
--//序列化: iqkit.serialize(obj)
--//反序列化：iqkit.deserialize(lua)
--//*******************************************//
function iqkit.serialize(obj)
    local lua = ""
    local t = type(obj)
    if t == "number" then
        lua = lua .. obj
    elseif t == "boolean" then
        lua = lua .. tostring(obj)
    elseif t == "string" then
        lua = lua .. string.format("%q", obj)
    elseif t == "table" then
        lua = lua .. "{\n"
    for k, v in pairs(obj) do
        lua = lua .. "[" .. serialize(k) .. "]=" .. serialize(v) .. ",\n"
    end
    local metatable = getmetatable(obj)
        if metatable ~= nil and type(metatable.__index) == "table" then
        for k, v in pairs(metatable.__index) do
            lua = lua .. "[" .. serialize(k) .. "]=" .. serialize(v) .. ",\n"
        end
    end
        lua = lua .. "}"
    elseif t == "nil" then
        return nil
    else
        error("can not serialize a " .. t .. " type.")
    end
    return lua
end
function iqkit.deserialize(lua)
    local t = type(lua)
    if t == "nil" or lua == "" then
        return nil
    elseif t == "number" or t == "string" or t == "boolean" then
        lua = tostring(lua)
    else
        error("can not unserialize a " .. t .. " type.")
    end
    lua = "return " .. lua
    local func = load(lua)
    if func == nil then
        return nil
    end
    return func()
end
--//*********************序列化工具类结束*************************//

--//*******************文件操作工具类*********************//
--//用于路径、文件名、后缀名等信息的处理，目录结构遍历
--//文件或路径存在的判断:
--//路径创建
--//文件读写
--//*******************************************//
--获取路径  
function iqkit.StripFileName(path)  
    return string.match(path, "(.+)/[^/]*%.%w+$") --*nix system  
    --return string.match(filename, “(.+)\\[^\\]*%.%w+$”) — windows  
end  
  
--获取文件名  
function iqkit.StripPath(path)  
    return string.match(path, ".+/([^/]*%.[^.]+)$") -- *nix system  
    --return string.match(filename, “.+\\([^\\]*%.%w+)$”) — *windows system  
end
--get filename
function iqkit.GetFileName(name)
	if StripPath(name)~=nil then
		name=StripPath(name)
	end
    local idx = name:match(".+()%.%w+")
    if(idx) then
        return name:sub(1, idx-1)
    else
        return name  
    end
end
--get file postfix  
function iqkit.GetExtension(name)  
    return name:match(".+%.(%w+)")
end
function iqkit.ls(rootpath, deep)
	if deep==nil then
		deep=0
	end
    for entry in lfs.dir(rootpath) do  
        if entry ~= '.' and entry ~= '..' then  
            local path = rootpath .. '/' .. entry  
            local attr = lfs.attributes(path)  
            print(path)
            local filename = entry	--GetFileName(entry)  
			for i=1,deep do
				ls_result=ls_result..'\t'
			end
            if attr.mode ~= 'directory' then  
				local postfix = GetExtension(entry)
				local file_info=filename..'\t'..attr.size .. '\t' .. attr.mode .. '\t' .. postfix..'\r\n'
				ls_result=ls_result..file_info
			else
				local directory_info=filename .. '\t' .. attr.mode..'\r\n'
				ls_result=ls_result..directory_info
                ls(path, deep+1)
            end  
        end  
	end
	return ls_result
end
function iqkit.FileExists(path)
	local file,err = io.open(path, "rb")
	if file then file:close() end
	return file ~= nil
end
function iqkit.CreateDirectory(path)
	if path~=nil then
		path=StripFileName(path)
		if file_exists(path)==false then
			lfs.mkdir(path)
		end
	end
end

function iqkit.FormatTime(time)
	local hour=math.floor(time/3600)
	local minute=math.floor((time-hour*3600)/60)
	local second=math.floor(time-hour*3600-minute*60)
	if hour>0 then
		hour=hour..'h:'
	else
		hour=''
	end
	if minute>0 then
		minute=minute..'m:'
	else
		minute=''
	end
	return hour..minute..second..'s'
end


--//********************封装结束***********************//
return iqkit