package open;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by sunshine on 2015/10/16.
 *
 */
public class ApiClientTest {
    public static void main(String[] args) throws IOException, APIException {
        // 设置自己的appid、secret
        String appId = "53l2LMnlG9Aawu4T8l";
        String appSecret = "wqzH8nG8c2nRZC6SlXLH0nLodC6WJg7P";
        int version = 1;
        String protocol = "http";
        // 创建一个ApiClient实例
        ApiClient apiClient = new ApiClient(appId, appSecret, version, protocol);
        // 做其他请求之前可能需要先获取token，因为api请求中必须要有access_token
        // reset的值设置为true则会重置原来的access_token，原来的会失效，如果设置为false，即仅仅获取access_token
        String access_token = apiClient.getAccessToken(false);

        // 设置环境，debug设置为true，则为测试环境，默认为false，真实环境下的接口有次数限制
        // 需要注意的是，debug的设置需要在请求之前设置才有效
//        apiClient.setDebug(true);
//        apiClient.setDebug(false);

        // 设置连接的超时时间，这个时间用于连接的超时和读取内容的超时(单位/毫秒)
        // 默认5000ms
        apiClient.setTimeout(10000);

        Map<String, String> params = new HashMap<>();
        params.put("access_token", access_token);
        params.put("device_id", "123123123");

        // get请求
        String json = apiClient.get("/device/status/online", params);
        System.out.println(json);

        // post请求
        params.put("online_status", "0");
        json = apiClient.post("/device/status/online", params);
        System.out.println(json);

        // put和delete请求和上面的请求方式相同 ...
    }
}
