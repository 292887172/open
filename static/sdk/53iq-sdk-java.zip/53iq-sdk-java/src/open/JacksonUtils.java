package open;

import org.codehaus.jackson.map.ObjectMapper;

import java.io.IOException;

public class JacksonUtils {
	
	private static ObjectMapper objectMapper = null;
	
	/**
	 * 使用泛型把json字符串转换成对应的JavaBean对象
	 * <br>(1).转换为普通的JavaBean： readValue(json,Student.class)
	 * <br>(2).转换为Map： readValue(json,Map.class)
	 * <br>(3).转换为List： readValue(json,List.class)
	 * <br>
	 * <br>注意：如果想要把json转换为特定类型的List，此时不能直接转换，因为readValue(json,List.class)返回的其实是Map类型的List集合
	 * 可以给第二个参数传入Student[].class转换为数组，然后使用Arrays.asList()方法把数组转换成特定类型的List。
	 * 
	 * @param content 原始的json字符串
	 * @param valueType JavaBean类型
	 * @return JavaBean对象
	 */
	public static <T> T readValue(String content,Class<T> valueType) throws IOException {
		if (objectMapper == null) {
			objectMapper = new ObjectMapper();
		}
		return objectMapper.readValue(content, valueType);

	}
	
	/**
	 * 把JavaBean转换成json字符串
	 * <br>(1).普通对象转换：toJson(Student)
	 * <br>(2).List 转换：toJson(List)
	 * <br>(3).Map 转换：toJson(Map)
	 * 
	 * @param object	JavaBean对象
	 * @return	json字符串
	 */
	public static String toJson(Object object) throws IOException {
		if(objectMapper == null){
			objectMapper = new ObjectMapper();
		}
		return objectMapper.writeValueAsString(object);

	}
}
