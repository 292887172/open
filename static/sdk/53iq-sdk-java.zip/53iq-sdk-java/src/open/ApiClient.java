package open;

import org.apache.http.Consts;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.annotation.NotThreadSafe;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.*;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by sunshine on 2015/10/16.
 *
 */
public class ApiClient {
    // 用户APP_ID
    private String appid;
    // 用户secret
    private String secret;
    private int version = 1;
    private String grantType = "client_credential";
    private String protocol = "http";
    // 连接超时（毫秒）
    private int timeout = 5000;
    private String domain = this.protocol+"://api.53iq.com/"+this.version+"/";
    private String access_token;
    private int expires = 0;
    private boolean debug = false;


    public ApiClient(String appid, String secret, int version, String protocol) {
        this.appid = appid;
        this.secret = secret;
        this.version = version;
        this.protocol = protocol;
    }

    public String getAppid() {
        return appid;
    }

    public void setAppid(String appid) {
        this.appid = appid;
    }

    public String getSecret() {
        return secret;
    }

    public void setSecret(String secret) {
        this.secret = secret;
    }

    public String getGrantType() {
        return grantType;
    }

    public void setGrantType(String grantType) {
        this.grantType = grantType;
    }

    public int getTimeout() {
        return timeout;
    }

    public void setTimeout(int timeout) {
        this.timeout = timeout;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public String getAccess_token() {
        return access_token;
    }

    public void setAccess_token(String access_token) {
        this.access_token = access_token;
    }

    public int getExpires() {
        return expires;
    }

    public void setExpires(int expires) {
        this.expires = expires;
    }

    public boolean isDebug() {
        return debug;
    }

    public void setDebug(boolean debug) {
        this.debug = debug;
        if (this.debug) {
            this.domain = this.protocol+"://api.53iq.com/"+this.version+"/";
        } else {
            this.domain = this.protocol+"://sandbox.api.53iq.com/"+this.version+"/";
        }
    }

    /**
     * 获取access_token
     *
     * @param reset 是否重置access_token
     * @return access_token
     * @throws IOException
     */
    public String getAccessToken(boolean reset) throws IOException, APIException {
        String text;
        Map<String, String> params = new HashMap<>();
        params.put("appid", this.appid);
        params.put("secret", this.secret);
        params.put("grant_type", this.grantType);
        if (reset) {
            text = this.post("/token", params);
        } else {
            text = this.get("/token", params);
        }
        TokenEntity tokenEntity = JacksonUtils.readValue(text, TokenEntity.class);
        assert tokenEntity != null;
        if (tokenEntity.getCode() == 0) {
            this.access_token = tokenEntity.getData().getAccess_token();
            this.expires = tokenEntity.getData().getExpires_in();
        } else {
            throw new APIException(tokenEntity.getCode(), tokenEntity.getMsg());
        }
        return this.access_token;
    }

    /**
     * get请求
     *
     * @param url    url
     * @param params 参数
     * @return json格式的字符串或者错误信息
     * @throws IOException
     */
    public String get(String url, Map<String, String> params) throws IOException {
        // 拼接参数
        url = this.joinUrl(this.domain, url);
        System.out.println(url);
        StringBuilder sb = new StringBuilder();
        if (params != null) {
            for (Map.Entry<String, String> entry : params.entrySet()) {
                sb.append(entry.getKey()).append("=").append(entry.getValue()).append("&");
            }
            String args = sb.subSequence(0, sb.length() - 1).toString();
            if (args.length() > 0) {
                url = url + "?" + args;
            }
        }
        try (CloseableHttpClient httpclient = HttpClients.createDefault()) {
            HttpGet httpGet = new HttpGet(url);
            httpGet.setConfig(getRequestConfig());
            try (CloseableHttpResponse response = httpclient.execute(httpGet)) {
                // 获取响应实体
                HttpEntity entity = response.getEntity();
                // 打印响应状态
                if (entity != null) {
                    return EntityUtils.toString(entity);
                }
            }
        }
        return "";
    }

    /**
     * post请求
     *
     * @param url    url
     * @param params Map参数
     * @return json字符串
     * @throws IOException
     */
    public String post(String url, Map<String, String> params) throws IOException {
        HttpPost httpPost = new HttpPost(this.joinUrl(this.domain, url));
        return this.request(params, httpPost);
    }

    /**
     * put请求
     *
     * @param url    url
     * @param params Map参数
     * @return json字符串
     * @throws IOException
     */
    public String put(String url, Map<String, String> params) throws IOException {
        HttpPut httpPut = new HttpPut(this.joinUrl(this.domain, url));
        return this.request(params, httpPut);
    }

    /**
     * delete请求
     *
     * @param url    url
     * @param params Map参数
     * @return json字符串
     * @throws IOException
     */
    public String delete(String url, Map<String, String> params) throws IOException {
        MyHttpDelete httpDelete = new MyHttpDelete(this.joinUrl(this.domain, url));
        return this.request(params, httpDelete);
    }


    /**
     * 发送http请求
     *
     * @param params 请求的参数
     * @param http   请求的实体类
     * @return json请求数据
     * @throws IOException
     */
    private String request(Map<String, String> params, HttpEntityEnclosingRequestBase http) throws IOException {
        http.setConfig(this.getRequestConfig());
        if (params != null) {
            List<NameValuePair> formParams = new ArrayList<>();
            for (Map.Entry<String, String> entry : params.entrySet()) {
                formParams.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
            }
            UrlEncodedFormEntity entity = new UrlEncodedFormEntity(formParams, Consts.UTF_8);
            http.setEntity(entity);
        }

        CloseableHttpClient httpclient = HttpClients.createDefault();
        try {
            CloseableHttpResponse response = httpclient.execute(http);
            try {
                // 获取响应实体
                HttpEntity entity = response.getEntity();
                if (entity != null) {
                    return EntityUtils.toString(entity);
                }
            } finally {
                response.close();
            }
        } finally {
            httpclient.close();
        }
        return "";
    }

    private RequestConfig getRequestConfig() {
        return RequestConfig.custom().setSocketTimeout(this.timeout).setConnectTimeout(this.timeout).build();
    }

    private String joinUrl(String base, String url) {
        if (url.startsWith("/")){
            url = url.substring(1, url.length());
        }
        return base + url;
    }
}

/**
 * token的实体类
 * 用于token与json数据之间的转换
 */
class TokenEntity {
    static class Data {
        private String access_token;
        private int expires_in;

        public String getAccess_token() {
            return access_token;
        }

        public void setAccess_token(String access_token) {
            this.access_token = access_token;
        }

        public int getExpires_in() {
            return expires_in;
        }

        public void setExpires_in(int expires_in) {
            this.expires_in = expires_in;
        }

        @Override
        public String toString() {
            return "Data{" +
                    "access_token='" + access_token + '\'' +
                    ", expires_in=" + expires_in +
                    '}';
        }
    }

    private int code = -1;
    private Data data;
    private String msg;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    @Override
    public String toString() {
        return "TokenEntity{" +
                "code=" + code +
                ", data=" + data +
                ", msg='" + msg + '\'' +
                '}';
    }
}


/**
 * 异常类
 */
class APIException extends Exception {
    public APIException(int code, String message) {
        super("APIError: " + code + ": " + message);
    }
}


/**
 * 自定义的HttpDelete,
 * 因为httpclient中自带的HttpDelete不可以设置entity的值
 * 查看源码可以看出HttpClient和HttpPost之类的继承的类不一样
 * 所以自己写一个继承自HttpEntityEnclosingRequestBase的类即可
 */
@NotThreadSafe
class MyHttpDelete extends HttpEntityEnclosingRequestBase {

    public static final String METHOD_NAME = "DELETE";

    public MyHttpDelete() {
        super();
    }

    public MyHttpDelete(String uri) {
        super();
        this.setURI(URI.create(uri));
    }

    public String getMethod() {
        return METHOD_NAME;
    }
}
