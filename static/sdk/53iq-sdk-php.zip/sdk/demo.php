<?php
/**
 * Date: 12/15/15
 * Time: 10:06 AM
 */
require_once("client.php");
$c = new EbRest("appid", "appsecret");


global $token;
if (!isset($token)) {
    // 获取access_token，不要频繁获取，每天有调用次数限制，请将token保存到自己的全局缓存中
    $token = $c->getAccessToken();
    echo $token . "\n";
}


// 设备状态
$deivceId = "45577338";
$payload = array();
$payload = "?access_token=$token";
$url = "https://api.53iq.com/$c->apiVersion/device/$deivceId/status/online$payload";
$r = $c->http($url, "GET");
echo $r . "\n";


// 调用图片api
$deivceId = "45577338";
$payload = array();
$payload["access_token"] = $token;
$payload["image_url"] = "http://www.53iq.com/static/img/home/130726logo.png";
$payload["data_type"] = 1;
$payload["data"] = "[$deivceId]";
$url = "https://api.53iq.com/$c->apiVersion/ad/push_kitchen_image";
$r = $c->http($url, "POST", $payload);
echo $r;


