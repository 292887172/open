53iq  sdk
=================

用于53iq开放平台的PHP SDK. 内含能直接使用的DEMO.


说明
-----

**如何申请appid和app secret**

这里申请: http://open.53iq.com/guide


**sdk使用教程**


License
---------------------

Copyright 2015 53IQ.

Licensed under the Apache License, Version 2.0: http://www.apache.org/licenses/LICENSE-2.0