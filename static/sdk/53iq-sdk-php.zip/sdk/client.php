<?php

/**
 * REST请求类
 */
class EbRest
{
    // 应用唯一标志
    protected $appId = null;
    // 密钥
    protected $appSecret = null;
    // api版本号
    public $apiVersion = 1;
    // 浏览器代理
    public $useragent = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome Safari/537.36';
    // 请求超时时间
    public $timeout = 30;
    // 连接超时时间
    public $connecttimeout = 30;
    // 是否验证ssl证书
    public $ssl_verifypeer = false;
    // 是否开启调试模式
    public $debug = false;

    /**
     * @param $appId 应用唯一标志
     * @param $appSecret 密钥
     * @param int $apiVersion api版本号
     */
    function __construct($appId, $appSecret, $apiVersion = 1)
    {
        $this->appId = $appId;
        $this->appSecret = $appSecret;
        $this->apiVersion = $apiVersion;
    }


    /**
     * 获取全局唯一票据
     * @return mixed
     */
    function getAccessToken()
    {
        $payload = "?appid=$this->appId&secret=$this->appSecret&grant_type=client_credential";
        $r = $this->http("https://api.53iq.com/$this->apiVersion/token$payload", "GET");
        $t = json_decode($r);
        return $t->data->access_token;
    }

    /**
     * @param $ch
     * @param $header
     * @return int
     */
    function getHeader($ch, $header)
    {
        $i = strpos($header, ':');
        if (!empty($i)) {
            $key = str_replace('-', '_', strtolower(substr($header, 0, $i)));
            $value = trim(substr($header, $i + 2));
            $this->http_header[$key] = $value;
        }
        return strlen($header);
    }

    /**
     * 发送http请求
     * @param $url
     * @param $method 请求方式（GET、POST、DELETE）
     * @param null $postfields POST或者DELETE请求时的参数数据，array()形式的键值对数据
     * @param array $headers 请求头
     * @return mixed 返回请求结果
     */
    function http($url, $method, $postfields = NULL, $headers = array())
    {
        $this->http_info = array();
        $ci = curl_init();
        /* Curl settings */
        curl_setopt($ci, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
        curl_setopt($ci, CURLOPT_USERAGENT, $this->useragent);
        curl_setopt($ci, CURLOPT_CONNECTTIMEOUT, $this->connecttimeout);
        curl_setopt($ci, CURLOPT_TIMEOUT, $this->timeout);
        curl_setopt($ci, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ci, CURLOPT_ENCODING, "");
        curl_setopt($ci, CURLOPT_SSL_VERIFYPEER, $this->ssl_verifypeer);
        if (version_compare(phpversion(), '5.4.0', '<')) {
            curl_setopt($ci, CURLOPT_SSL_VERIFYHOST, 1);
        } else {
            curl_setopt($ci, CURLOPT_SSL_VERIFYHOST, 2);
        }
        curl_setopt($ci, CURLOPT_HEADERFUNCTION, array($this, 'getHeader'));
        curl_setopt($ci, CURLOPT_HEADER, FALSE);

        switch ($method) {
            case 'POST':
                curl_setopt($ci, CURLOPT_POST, TRUE);
                if (!empty($postfields)) {
                    curl_setopt($ci, CURLOPT_POSTFIELDS, $postfields);
                    $this->postdata = $postfields;
                }
                break;
            case 'DELETE':
                curl_setopt($ci, CURLOPT_CUSTOMREQUEST, 'DELETE');
                if (!empty($postfields)) {
                    $url = "{$url}?{$postfields}";
                }
        }
        curl_setopt($ci, CURLOPT_URL, $url);
        curl_setopt($ci, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ci, CURLINFO_HEADER_OUT, TRUE);

        $response = curl_exec($ci);
        $this->http_code = curl_getinfo($ci, CURLINFO_HTTP_CODE);
        $this->http_info = array_merge($this->http_info, curl_getinfo($ci));
        $this->url = $url;

        if ($this->debug) {
            echo "=====post data======\r\n";
            var_dump($postfields);

            echo "=====headers======\r\n";
            print_r($headers);

            echo '=====request info=====' . "\r\n";
            print_r(curl_getinfo($ci));

            echo '=====response=====' . "\r\n";
            print_r($response);
        }
        curl_close($ci);
        return $response;
    }
}

