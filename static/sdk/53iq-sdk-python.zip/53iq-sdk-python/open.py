import json
import requests
from urllib import request

__version__ = '1.0.0'
__author__ = 'sunshine'


class APIError(BaseException):
    """
    raise APIError if receiving json message indicating failure.
    """
    def __init__(self, error_code, error):
        self.error_code = error_code
        self.error = error

    def __str__(self):
        return 'APIError: %s: %s' % (self.error_code, self.error)


def validate_access_token(func):
    """
    装饰器
    验证access_token是否存在
    :param func:
    :return:
    """
    def wrapped_request(self, *args, **kwargs):
        if self.access_token:
            if len(args) <= 1:
                args = list(args)
                args.append({"access_token": self.access_token})
                args = tuple(args)
            else:
                args[1]['access_token'] = self.access_token
            kwargs['timeout'] = self.timeout
            return func(self, *args, **kwargs)
        else:
            return json.dumps({"code": 41003, "msg": "missing access_token"})
    return wrapped_request


def get_access_token(url, app_id, app_secret, grant_type="client_credential", reset=False, timeout=5):
    """
    获取access_token
    :param url: 请求url
    :param app_id: 用户APP_ID
    :param app_secret: 用户app_secret
    :param grant_type: 统一填写 "client_credential"
    :param reset: 是否重置access_token
    :param timeout: 请求超时时间
    :return:
    """
    args = {"appid": app_id, "secret": app_secret, "grant_type": grant_type}
    if reset:
        resp = requests.post(url, data=args, timeout=timeout)
    else:
        resp = requests.get(url, params=args, timeout=timeout)
    result = json.loads(resp.text)
    if result['code'] == 0:
        access_token = result['data']['access_token']
        expires = result['data']['expires_in']
        return access_token, expires
    else:
        raise APIError(result['code'], result['msg'])


class APIClient(object):
    def __init__(self, app_id, app_secret, version=1, secret=False, debug=False, response_type='code', timeout=5):
        # appid
        self.appid = str(app_id)
        self.app_secret = str(app_secret)
        # 接口版本号
        self.version = str(version)
        # 是否使用https
        self.secret = secret
        self.protocol = 'https' if self.secret else 'http'
        self.grant_type = "client_credential"
        self.response_type = response_type
        self.timeout = timeout
        self.debug = debug
        self.domain = ""
        self.set_domain()
        self.response = None
        self.access_token = None
        self.expires = 0

    @validate_access_token
    def get(self, url, params=None, **kwargs):
        self.response = requests.get(request.urljoin(self.domain, url), params, **kwargs)
        return self.response.text

    @validate_access_token
    def post(self, url, data=None, json=None, **kwargs):
        self.response = requests.post(request.urljoin(self.domain, url), data, json, **kwargs)
        return self.response.text

    @validate_access_token
    def put(self, url, data=None, **kwargs):
        self.response = requests.put(request.urljoin(self.domain, url), data, **kwargs)
        return self.response.text

    @validate_access_token
    def delete(self, url, data=None, **kwargs):
        kwargs['data'] = data
        self.response = requests.delete(request.urljoin(self.domain, url), **kwargs)
        return self.response.text

    def set_domain(self):
        if self.debug:
            self.domain = self.protocol+"://sandbox.api.53iq.com/"+self.version+"/"
        else:
            self.domain = self.protocol+"://api.53iq.com/"+self.version+"/"

    def get_access_token(self):
        """
        获取access_token，每个APPID和app_secret每天是有次数限制的
        :return:
        """
        self.access_token, self.expires = \
            get_access_token(request.urljoin(self.domain, "token"),
                             self.appid, self.app_secret, self.grant_type, False, self.timeout)
        return self.access_token, self.expires

    def set_access_token(self, access_token, expires):
        """
        设置access_token，可以自行设置
        :param access_token:
        :param expires:
        :return:
        """
        self.access_token = str(access_token)
        self.expires = int(expires)

    def refresh_access_token(self):
        """
        刷新access_token，会重置原来的token，原来的token值会失效
        :return:
        """
        self.access_token, self.expires = \
            get_access_token(request.urljoin(self.domain, "token"),
                             self.appid, self.app_secret, self.grant_type, True, self.timeout)


if __name__ == '__main__':
    client = APIClient("53l2LMnlG9Aawu4T8l", "wqzH8nG8c2nRZC6SlXLH0nLodC6WJg7P", debug=False)
    # 在调用api请求前需要先获取access_token
    # 可以调用 client.get_access_token()，也可以自行设置 set_access_token
    # 在自行设置的时候需要先通过get_access_token()的方法去获取access_token
    client.get_access_token()
    print(client.access_token)
    # client.refresh_access_token()
    # print(client.access_token)
    # a, e = get_access_token(client.api_url, client.appid, client.app_secret, client.grant_type)
    # print(a, e)
    # client.access_token = a
    # result = client.get("device/status/online", {"device_id": 123123123})
    # print(result)
    # result = client.post("http://api.53iq.com/1/device/status/online", {"device_id": 123123123, "online_status": 0})
    # print(result)
    # client.delete("http://api.53iq.com/1/device/status/online")
    # client.validate_access_token()
    # url = request.urljoin("http://api.53iq.com/1/", "/device/status/online")
    # print(url)

    pass
