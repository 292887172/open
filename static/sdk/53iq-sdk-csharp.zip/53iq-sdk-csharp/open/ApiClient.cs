﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace open
{
    public class ApiClient
    {
        private string appid;

        public string Appid
        {
            get { return appid; }
            set { appid = value; }
        }
        private string secret;

        public string Secret
        {
            get { return secret; }
            set { secret = value; }
        }

        private int version = 1;
        public int Version
        {
            get { return version; }
            set { version = value; }
        }

        private string protocol = "http";
        public string Protocol
        {
            get { return protocol; }
            set { protocol = value; }
        }

        private string grant_type = "client_credential";

        public string Grant_type
        {
            get { return grant_type; }
            set { grant_type = value; }
        }
        private int timeout = 5000;

        public int Timeout
        {
            get { return timeout; }
            set { timeout = value; }
        }
        private bool debug = false;

        public bool Debug
        {
            get { return debug; }
            set { debug = value; }
        }
        private string domain = "http://api.53iq.com/1";

        public string Domain
        {
            get { return domain; }
            set { domain = value; }
        }
        private string access_token;

        public string Access_token
        {
            get { return access_token; }
            set { access_token = value; }
        }
        private int expires = 0;

        public int Expires
        {
            get { return expires; }
            set { expires = value; }
        }


        public ApiClient(string appid, string secret, int version=1, string protocol="http")
        {
            this.appid = appid;
            this.secret = secret;
            this.version = version;
            this.protocol = protocol;
        }

        /// <summary>
        /// 设置请求是否为debug
        /// </summary>
        /// <param name="debug"></param>
        public void SetDebug(bool debug)
        {
            this.debug = debug;
            if (debug)
            {
                this.domain = this.protocol+"://sandbox.api.53iq.com/"+this.version;
            }
            else
            {
                this.domain = this.protocol+"://api.53iq.com/"+this.version;
            }
            Console.WriteLine(this.domain);
        }

        /// <summary>
        /// 获取access_token
        /// </summary>
        /// <param name="reset"></param>
        /// <returns></returns>
        public string GetAccessToken(bool reset)
        {
            string result = "";
            IDictionary<string, string> args = new Dictionary<string, string>();
            args.Add("appid", this.appid);
            args.Add("secret", this.secret);
            args.Add("grant_type", this.grant_type);
            if (reset)
            {
                result = this.HttpPost("/token", args);
            }
            else
            {
                result = this.HttpGet("/token", args);
            }
            Console.WriteLine(result);
            JObject json = (JObject)JsonConvert.DeserializeObject(result);
            Console.WriteLine(json);
            Console.WriteLine(json["code"]);
            if (Convert.ToInt32(json["code"].ToString()) == 0)
            {
                this.access_token = json["data"]["access_token"].ToString();
                this.expires = Convert.ToInt32(json["data"]["expires_in"].ToString());
            }
            else
            {
                // 抛出异常
                throw new ApiException("ApiException: "+json["code"].ToString()+": "+json["msg"].ToString());
            }
            return this.access_token;
        }

        /// <summary>
        /// Http get请求
        /// </summary>
        /// <param name="url"></param>
        /// <param name="args"></param>
        /// <returns></returns>
        public string HttpGet(string url, IDictionary<string, string> args)
        {
            url = this.JoinUrl(this.domain, url);
            string pms = this.JoinParams(args);
            if (pms != null && pms.Length > 0)
            {
                url = url + "?" + pms;
            }

            return this.Request("GET", url);
        }

        /// <summary>
        /// http post请求
        /// </summary>
        /// <param name="url"></param>
        /// <param name="args"></param>
        /// <returns></returns>
        public string HttpPost(string url, IDictionary<string, string> args)
        {
            url = this.JoinUrl(this.domain, url);
            string body = this.JoinParams(args);
            Console.WriteLine(body);
            return this.Request("POST", url, body);
        }

        /// <summary>
        /// http put请求
        /// </summary>
        /// <param name="url"></param>
        /// <param name="args"></param>
        /// <returns></returns>
        public string HttpPut(string url, IDictionary<string, string> args)
        {
            url = this.JoinUrl(this.domain, url);
            string body = this.JoinParams(args);
            return this.Request("PUT", url, body);
        }

        /// <summary>
        /// http delete请求
        /// </summary>
        /// <param name="url"></param>
        /// <param name="args"></param>
        /// <returns></returns>
        public string HttpDelete(string url, IDictionary<string, string> args)
        {
            url = this.JoinUrl(this.domain, url);
            string body = this.JoinParams(args);
            return this.Request("DELETE", url, body);
        }

        /// <summary>
        /// http请求的封装
        /// </summary>
        /// <param name="method"></param>
        /// <param name="url"></param>
        /// <param name="body"></param>
        /// <param name="contentType"></param>
        /// <returns></returns>
        private string Request(string method, string url, string body = null, string contentType = "application/x-www-form-urlencoded")
        {
            HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(url);
            httpWebRequest.Method = method;
            httpWebRequest.Timeout = this.timeout;
            httpWebRequest.ContentType = contentType;

            if (body != null)
            {
                byte[] btBodys = Encoding.UTF8.GetBytes(body);
                httpWebRequest.ContentLength = btBodys.Length;
                using (Stream stream = httpWebRequest.GetRequestStream())
                {
                    stream.Write(btBodys, 0, btBodys.Length);
                }
            }

            using (HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse())
            {
                using (StreamReader streamReader = new StreamReader(httpWebResponse.GetResponseStream()))
                {
                    string responseContent = streamReader.ReadToEnd();
                    return responseContent;
                }
            }
                
        }

        /// <summary>
        /// 组合参数
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
        private string JoinParams(IDictionary<string, string> args)
        {
            string pms = null;
            if (args != null)
            {
                StringBuilder sb = new StringBuilder();
                foreach (KeyValuePair<string, string> kvp in args)
                {
                    sb.Append(kvp.Key + "=" + kvp.Value + "&");
                }
                pms = sb.ToString().Substring(0, sb.Length - 1);
            }
            return pms;
        }

        /// <summary>
        /// 连接url
        /// </summary>
        /// <param name="baseurl"></param>
        /// <param name="url"></param>
        /// <returns></returns>
        private string JoinUrl(string baseurl, string url)
        {
            return baseurl + url;
        }

    }


    /// <summary>
    /// 自定义api异常类
    /// </summary>
    class ApiException : ApplicationException
    {
        public ApiException() { }
        public ApiException(string message)
            : base(message) { }
        public ApiException(string message, Exception inner)
            : base(message, inner) { }
        //public PayOverflowException(System.Runtime.Serialization.SerializationInfo info,
        //    System.Runtime.Serialization.StreamingContext context)
        //    : base(info, context) { }
    }

}
