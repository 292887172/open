﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace open
{
    class Program
    {
        static void Main(string[] args)
        {
            string appid = "53o2R8j7OmFDaGujse";
            string secret = "DZHaIN6OF4H9icdr6zPXkHGTWi9bNiJr";
            // 接口版本号
            int version = 1;
            // 协议https 或者 http， 如果是其他的字符串结果是未知的
            string protocol = "http";
            ApiClient apiClient = new ApiClient(appid, secret, version, protocol);
            
            string token = apiClient.GetAccessToken(false);
            // string token = apiClient.GetAccessToken(true);
            Console.WriteLine(token);
            IDictionary<string, string> pms = new Dictionary<string, string>();
            pms.Add("access_token", token);
            pms.Add("device_id", "123123123");
            
            string json = apiClient.HttpGet("/device/status/online", pms);
            Console.WriteLine(json);
            pms.Add("online_status", "0");
            json = apiClient.HttpPost("/device/status/online", pms);
            Console.WriteLine(json);

            // 其他请求类似
        }

    }
}
