pc_conf = {
    'name': "森泰油烟机",
    'model': "STX1",
    'key': "xxxxxxxxxxxxxxxxxxxxx",
    'secret': "yyyyyyyy",
    'functions': [
        {
            'id': 1,
            'no': 1,
            'name': "POWER",
            'title': "开关",
            'length': 8,
            'values': [
                0,
                1
            ],
            'value_des': {
                0: "关",
                1: "开"
            },
            'value': 0,
            'unit': "",
            'type': "bool",
            'widget': "button",
            'permission': "777",
            'triggers': [
            ]
        },

        {
            'id': 2,
            'no': 2,
            'name': "LAMP",
            'title': "照明",
            'length': 8,
            'values': [
                0,
                1
            ],
            'value_des': {
                0: "关",
                1: "开"
            },
            'value': 0,
            'unit': "",
            'type': "bool",
            'widget': "button",
            'permission': "777",
            'triggers': [
            ]
        },{
            'id': 3,
            'no': 3,
            'name': "FAN_LEFT",
            'title': "风机",
            'length': 8,
            'values': [
                0,3
            ],
            'value_des': {
                0: "关",
                1: "小风",
                2: "中风",
                3: "大风"
            },
            'value': 0,
            'unit': "",
            'type': "int",
            'widget': "button",
            'permission': "777",
            'triggers': [
            ]
        },
        {
            'id': 4,
            'no': 4,
            'name': "DISINFECT",
            'link':"DISINFECT_TIME",
            'title': "消毒/烘干",
            'length': 8,
            'values': [
                0,2,4
            ],
            'value_des': {
                0: "关",
                2: "消毒60分钟",
                4: "烘干60分钟"
            },
            'value': 0,
            'unit': "",
            'type': "enum",
            'widget': "button",
            'permission': "777",
            'triggers': [
            ]
        },

        {
            'id': 6,
            'no': 6,
            'name': "WASH",
            'title': "清洗",
            'link':'WASH_TIME',
            'length': 8,
            'value_des': {
                0: "关",
                1: "30分钟",
                2: "60分钟",
                3: "90分钟"
            },
            'values': [
                0,3
            ],
            'value': 0,
            'unit': "",
            'type': "int",
            'widget': "button",
            'permission': "777"
        },
        {
            'id': 8,
            'no': 8,
            'name': "LAMP_MOOD",
            'title': "氛围灯",
            'length': 8,
            'values': [
                0,
                1
            ],
            'value_des': {
                0: "关",
                1: "开"
            },
            'value': 0,
            'unit': "",
            'type': "bool",
            'widget': "button",
            'permission': "777",
            'triggers': [
            ]
        },
        {
            'id': 9,
            'no': 9,
            'name': "WARM",
            'title': "保温",
            'length': 8,
            'values': [
                0,
                1
            ],
            'value_des': {
                0: "关",
                1: "开"
            },
            'value': 0,
            'unit': "",
            'type': "bool",
            'widget': "button",
            'permission': "777",
            'triggers': [
            ]
        },
        {
            'id': 10,
            'no': 10,
            'name': "MISFIRE_LEFT",
            'title': "左定时熄火开关",
            'length': 8,
            'values': [
                0,
                3

            ],
            'value_des': {
                0: "正常",
                1: "马上关",
                2: "延时30秒",
                3: "延时1分钟"
            },
            'value': 0,
            'unit': "",
            'type': "int",
            'widget': "button",
            'permission': "777",
            'triggers': [
            ]
        },
        {
            'id': 11,
            'no': 11,
            'name': "MISFIRE_RIGHT",
            'title': "右定时熄火开关",
            'length': 8,
            'values': [
                0,
                3

            ],
            'value_des': {
                 0: "正常",
                1: "马上关",
                2: "延时30秒",
                3: "延时1分钟"
            },
            'value': 0,
            'unit': "",
            'type': "int",
            'widget': "button",
            'permission': "777",
            'triggers': [
            ]
        },
        {
            'id': 12,
            'no': 12,
            'name': "FIRE_LEFT",
            'title': "左火焰信号",
            'length': 8,
            'values': [
                0,
                1
            ],
            'value_des': {
                0: "关",
                1: "开"
            },
            'value': 0,
            'unit': "",
            'type': "bool",
            'widget': "button",
            'permission': "444",
            'triggers': [
            ]
        },
        {
            'id': 13,
            'no': 13,
            'name': "FIRE_RIGHT",
            'title': "右火焰信号",
            'length': 8,
            'values': [
                0,
                1
            ],
            'value_des': {
                0: "关",
                1: "开"
            },
            'value': 0,
            'unit': "",
            'type': "bool",
            'widget': "button",
            'permission': "444",
            'triggers': [
            ]
        },
        {
            'id': 5,
            'no': 5,
            'name': "DISINFECT_TIME",
            'title': "消毒/烘干倒计时",
            'length': 16,
            'values': [
                0,
                65535
            ],
            'value_des': {

            },
            'value': 0,
            'unit': "s",
            'type': "int",
            'widget': "input",
            'permission': "777",
            'triggers': [
            ]
        },

        {
            'id': 7,
            'no': 7,
            'name': "WASH_TIME",
            'title': "清洗倒计时",
            'length': 16,
            'values': [
                0,
                65535
            ],
            'value_des': {

            },
            'value': 0,
            'unit': "s",
            'type': "int",
            'widget': "input",
            'permission': "777",
            'triggers': [
            ]
        }
    ],
    'faults': [
        {
            'code': "1",
            'title': "烟雾报警"
        },
        {
            'code': "2",
            'title': "电机故障"
        }
    ],
    'params': [
        {
            'id': 1,
            'no': 1,
            'name': "AIR_THRESHOLD",
            'title': "气敏阈值",
            'length': 1,
            'value': "0.6"
        }
    ]
};